// Generator PDF „Wstępne zestawienie energii i wybranych emisji” — A4, działa w całości w przeglądarce
// (dane nie trafiają na serwer). jsPDF ładowany dynamicznie dopiero po kliknięciu. Testy: tests/emissions-pdf.test.ts.
import type { jsPDF as JsPDFType } from 'jspdf';
import { EMISSION_FACTORS as F, type FactorSource } from '../data/emission-factors.ts';
import { fmt, perLitre, gasPerM3, tonnes, type EmissionResult } from './emissions.ts';

export type PdfAssets = { inter400: string; inter600: string; cormorant500: string; logoPng: string | null }; // base64 (logo jako data URL)

export const DISCLAIMER =
  'Dokument opiera się na danych podanych przez użytkownika. Nie stanowi audytu, certyfikatu ani potwierdzenia zgodności z obowiązkiem raportowania ESG.';

const C = {
  navy: [26, 30, 64],
  ink: [35, 38, 63],
  muted: [107, 106, 116],
  taupe: [111, 84, 73],
  gold: [194, 162, 122],
  goldL: [230, 210, 176],
  ivory: [251, 248, 244],
  cream: [244, 238, 231],
  line: [228, 217, 205],
  white: [255, 255, 255],
} as const;
type RGB = readonly [number, number, number];

const PAGE_W = 210, PAGE_H = 297, M = 18, CW = PAGE_W - 2 * M, FOOT = 16;

const isoDate = (d: Date) => d.toLocaleDateString('pl-PL', { day: '2-digit', month: '2-digit', year: 'numeric' });
const dateTime = (d: Date) => `${isoDate(d)}, ${d.toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' })}`;
const pubDate = (s: string) => (/^\d{4}-\d{2}-\d{2}$/.test(s) ? s.split('-').reverse().join('.') : s);

export function fileName(r: EmissionResult, now: Date): string {
  const slug = (s: string) =>
    s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ł/g, 'l').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
  const parts = ['zestawienie-emisji', slug(r.inputs.company), slug(r.inputs.period) || now.toISOString().slice(0, 10)].filter(Boolean);
  return `${parts.join('-')}.pdf`;
}

export function buildPdf(JsPDF: typeof JsPDFType, r: EmissionResult, a: PdfAssets, now = new Date()): JsPDFType {
  const doc = new JsPDF({ unit: 'mm', format: 'a4', compress: true });
  doc.addFileToVFS('inter-400.ttf', a.inter400);
  doc.addFileToVFS('inter-600.ttf', a.inter600);
  doc.addFileToVFS('cormorant-500.ttf', a.cormorant500);
  doc.addFont('inter-400.ttf', 'Inter', 'normal');
  doc.addFont('inter-600.ttf', 'Inter', 'bold');
  doc.addFont('cormorant-500.ttf', 'Cormorant', 'normal');
  doc.setProperties({
    title: 'Wstępne zestawienie energii i wybranych emisji',
    subject: r.inputs.company ? `${r.inputs.company} — ${r.inputs.period}` : r.inputs.period,
    author: 'Narzędzie MGT Finance (dane użytkownika)',
    creator: 'mgtfinance.eu',
  });
  doc.setLineHeightFactor(1.35);

  let y = 0;
  const color = (c: RGB) => doc.setTextColor(c[0], c[1], c[2]);
  const fill = (c: RGB) => doc.setFillColor(c[0], c[1], c[2]);
  const stroke = (c: RGB) => doc.setDrawColor(c[0], c[1], c[2]);
  const font = (f: 'Inter' | 'Cormorant', s: 'normal' | 'bold', size: number) => { doc.setFont(f, s); doc.setFontSize(size); };
  const lh = (size: number) => (size * 0.3528) * 1.35; // wysokość wiersza w mm
  const ensure = (h: number) => { if (y + h > PAGE_H - FOOT - 4) { doc.addPage(); y = M; } };
  const para = (text: string, size = 9, c: RGB = C.ink, width = CW, x = M, style: 'normal' | 'bold' = 'normal') => {
    font('Inter', style, size); color(c);
    const lines = doc.splitTextToSize(text, width) as string[];
    for (const ln of lines) { ensure(lh(size)); doc.text(ln, x, y, { baseline: 'top' }); y += lh(size); }
  };
  const heading = (text: string) => {
    ensure(24);
    y += 2;
    font('Cormorant', 'normal', 15); color(C.navy);
    doc.text(text, M, y, { baseline: 'top' });
    y += 7;
    stroke(C.goldL); doc.setLineWidth(0.3); doc.line(M, y, M + CW, y);
    y += 3.5;
  };
  const bullet = (text: string, size = 8.6) => {
    font('Inter', 'normal', size);
    const lines = doc.splitTextToSize(text, CW - 5) as string[];
    ensure(lh(size) * Math.min(lines.length, 2));
    fill(C.gold); doc.circle(M + 1.2, y + lh(size) / 2 - 0.2, 0.7, 'F');
    color(C.ink);
    for (const ln of lines) { ensure(lh(size)); doc.text(ln, M + 5, y, { baseline: 'top' }); y += lh(size); }
    y += 0.8;
  };

  // ——— Nagłówek
  fill(C.ivory); doc.rect(0, 0, PAGE_W, 36, 'F');
  stroke(C.gold); doc.setLineWidth(0.4); doc.line(0, 36, PAGE_W, 36);
  if (a.logoPng) doc.addImage(a.logoPng, 'PNG', M, 11, 34, 13.8); // 200×81 px
  font('Inter', 'normal', 7.5); color(C.taupe);
  doc.text('Narzędzie MGT Finance · mgtfinance.eu', PAGE_W - M, 15, { align: 'right' });
  doc.text(`Wygenerowano: ${dateTime(now)}`, PAGE_W - M, 19.5, { align: 'right' });
  doc.text(`Wersja współczynników: ${F.version}`, PAGE_W - M, 24, { align: 'right' });
  y = 46;

  font('Cormorant', 'normal', 24); color(C.navy);
  for (const ln of doc.splitTextToSize('Wstępne zestawienie energii i wybranych emisji', CW) as string[]) { doc.text(ln, M, y, { baseline: 'top' }); y += 9; }
  y += 2;

  // Firma i okres
  const meta: [string, string][] = [
    ['Firma', r.inputs.company || 'nie podano'],
    ['Okres', r.inputs.period || 'nie podano'],
  ];
  for (const [k, v] of meta) {
    font('Inter', 'normal', 7.5); color(C.taupe); doc.text(k.toUpperCase(), M, y, { baseline: 'top', charSpace: 0.3 });
    font('Inter', 'bold', 10.5); color(C.navy);
    const lines = (doc.splitTextToSize(v, CW - 24) as string[]).slice(0, 3);
    lines.forEach((ln, n) => doc.text(ln, M + 24, y - 0.6 + n * lh(10.5), { baseline: 'top' }));
    y += Math.max(lines.length * lh(10.5), 5.5) + 1.5;
  }
  y += 2;

  // Zastrzeżenie — widoczne na pierwszej stronie
  font('Inter', 'bold', 8.8);
  const disc = doc.splitTextToSize(DISCLAIMER, CW - 12) as string[];
  const dh = disc.length * lh(8.8) + 9.5;
  fill(C.ivory); stroke(C.gold); doc.setLineWidth(0.35); doc.roundedRect(M, y, CW, dh, 2, 2, 'FD');
  fill(C.navy); doc.rect(M, y, 1.6, dh, 'F');
  color(C.navy); disc.forEach((ln, n) => doc.text(ln, M + 6, y + 3.5 + n * lh(8.8), { baseline: 'top' }));
  font('Inter', 'normal', 7.8); color(C.muted);
  doc.text('Wyniki obejmują wyłącznie CO₂ (bez CH₄ i N₂O), więc nie są wartościami w CO₂e.', M + 6, y + 3.5 + disc.length * lh(8.8) + 1, { baseline: 'top' });
  y += dh + 6;

  // ——— Wyniki: kafelki
  const tiles: [string, string, number, RGB][] = [
    ['Scope 1', 'paliwa spalane przez firmę', r.scope1Kg, C.navy],
    ['Scope 2', 'energia elektryczna, location-based', r.scope2Kg, C.gold],
    ['Razem', 'Scope 1 + Scope 2, tylko CO₂', r.totalKg, C.ink],
  ];
  const tw = (CW - 8) / 3, th = 25;
  ensure(th + 4);
  tiles.forEach(([t, sub, kg, c], n) => {
    const x = M + n * (tw + 4);
    fill(n === 2 ? C.navy : C.white); stroke(C.line); doc.setLineWidth(0.3); doc.roundedRect(x, y, tw, th, 2, 2, n === 2 ? 'F' : 'FD');
    if (n < 2) { fill(c); doc.rect(x, y + 3, 1.4, th - 6, 'F'); }
    const tc: RGB = n === 2 ? C.white : C.navy;
    font('Inter', 'bold', 8); color(n === 2 ? C.goldL : C.taupe); doc.text(t.toUpperCase(), x + 5, y + 4.5, { baseline: 'top', charSpace: 0.3 });
    font('Inter', 'bold', 15); color(tc); doc.text(`${tonnes(kg)} t CO₂`, x + 5, y + 10, { baseline: 'top' });
    font('Inter', 'normal', 7); color(n === 2 ? [220, 214, 228] : C.muted); doc.text(sub, x + 5, y + 18.5, { baseline: 'top' });
  });
  y += th + 7;

  // ——— Wykres
  heading('Emisje według źródeł (t CO₂)');
  const lines = [...r.lines].sort((p, q) => q.co2Kg - p.co2Kg);
  const max = Math.max(...lines.map((l) => l.co2Kg), 1);
  const labelW = 62, valW = 26, barW = CW - labelW - valW - 4;
  for (const l of lines) {
    font('Inter', 'normal', 8);
    const lab = (doc.splitTextToSize(l.label + (l.estimated ? ' *' : ''), labelW - 2) as string[]).slice(0, 2);
    const rowH = Math.max(lab.length * lh(8), 6) + 1.5;
    ensure(rowH);
    color(C.ink); lab.forEach((ln, n) => doc.text(ln, M, y + n * lh(8), { baseline: 'top' }));
    fill(C.cream); doc.roundedRect(M + labelW, y + 0.5, barW, 3.6, 1.8, 1.8, 'F');
    const w = Math.max((l.co2Kg / max) * barW, l.co2Kg > 0 ? 1.2 : 0);
    if (w > 0) { fill(l.scope === 1 ? C.navy : C.gold); doc.roundedRect(M + labelW, y + 0.5, w, 3.6, 1.8, 1.8, 'F'); }
    font('Inter', 'bold', 8); color(C.navy); doc.text(tonnes(l.co2Kg), M + CW, y, { baseline: 'top', align: 'right' });
    y += rowH;
  }
  font('Inter', 'normal', 7.2); color(C.muted);
  ensure(6);
  fill(C.navy); doc.rect(M, y + 1, 3, 2.4, 'F'); doc.text('Scope 1', M + 4.5, y + 0.6, { baseline: 'top' });
  fill(C.gold); doc.rect(M + 22, y + 1, 3, 2.4, 'F'); doc.text('Scope 2', M + 26.5, y + 0.6, { baseline: 'top' });
  if (lines.some((l) => l.estimated)) doc.text('* wartość szacowana (tryb szacunkowy floty)', M + 46, y + 0.6, { baseline: 'top' });
  y += 6;

  // ——— Tabela energii i emisji
  heading('Zużycie energii i emisje');
  const cols = [
    { h: 'Pozycja', w: 52, a: 'left' as const },
    { h: 'Zużycie', w: 30, a: 'right' as const },
    { h: 'Energia [kWh]', w: 28, a: 'right' as const },
    { h: 'Energia [MWh]', w: 24, a: 'right' as const },
    { h: 'Scope', w: 14, a: 'center' as const },
    { h: 't CO₂', w: CW - 148, a: 'right' as const },
  ];
  const row = (cells: string[], opts: { bold?: boolean; head?: boolean; fillRow?: RGB } = {}) => {
    const size = opts.head ? 7 : 8;
    font('Inter', opts.bold || opts.head ? 'bold' : 'normal', size);
    const wrapped = cells.map((c, n) => (doc.splitTextToSize(c, cols[n].w - 2.5) as string[]));
    const h = Math.max(...wrapped.map((w) => w.length)) * lh(size) + 3;
    ensure(h);
    if (opts.fillRow) { fill(opts.fillRow); doc.rect(M, y, CW, h, 'F'); }
    let x = M;
    wrapped.forEach((w, n) => {
      const col = cols[n];
      const tx = col.a === 'left' ? x + 1 : col.a === 'right' ? x + col.w - 1 : x + col.w / 2;
      color(opts.head ? C.taupe : C.ink);
      w.forEach((ln, k) => doc.text(ln, tx, y + 1.5 + k * lh(size), { baseline: 'top', align: col.a }));
      x += col.w;
    });
    y += h;
    stroke(C.line); doc.setLineWidth(0.2); doc.line(M, y, M + CW, y);
  };
  row(cols.map((c) => c.h), { head: true });
  for (const l of r.lines) {
    row([
      l.label + (l.estimated ? ' *' : ''),
      `${fmt(l.amount, l.amount % 1 && l.amount < 100 ? 1 : 0)} ${l.amountUnit}`,
      fmt(l.energyKwh),
      fmt(l.energyKwh / 1000, 2),
      String(l.scope),
      tonnes(l.co2Kg),
    ]);
  }
  row(['Razem (Scope 1 + Scope 2)', '', fmt(r.energy.totalKwh), fmt(r.energy.totalKwh / 1000, 2), '1 + 2', tonnes(r.totalKg)], { bold: true, fillRow: C.cream });
  y += 2;
  para(`Energia elektryczna: ${fmt(r.energy.electricityKwh)} kWh (${fmt(r.energy.electricityKwh / 1000, 2)} MWh). Energia z paliw: ${fmt(r.energy.fuelsKwh)} kWh (${fmt(r.energy.fuelsKwh / 1000, 2)} MWh) — przeliczona z ilości paliwa przez wartość opałową, bez rozbicia na energię odnawialną i nieodnawialną.`, 7.8, C.muted);

  // ——— Dane wejściowe
  heading('Dane wejściowe');
  const inputs: string[] = [];
  inputs.push(`Energia elektryczna kupiona z sieci: ${r.inputs.electricityKwh === null ? 'nie podano' : `${fmt(r.inputs.electricityKwh)} kWh`} — dane użytkownika${r.inputs.greenClaim ? '; użytkownik wskazał umowę na „zieloną” energię (nie zmienia wyniku location-based)' : ''}.`);
  if (r.inputs.fleetMode === 'litres') {
    const parts = (['petrol', 'diesel', 'lpg'] as const).map((k) => `${F.fuels[k].label.toLowerCase()}: ${r.inputs.litres[k] === null ? 'nie podano' : `${fmt(r.inputs.litres[k] as number)} l`}`);
    inputs.push(`Paliwo floty (litry z faktur lub kart paliwowych) — ${parts.join('; ')}. Dane użytkownika.`);
  } else {
    inputs.push('Paliwo floty — tryb szacunkowy (liczba pojazdów × przebieg × spalanie). Wartości szacowane:');
    for (const n of r.estimatedNotes) inputs.push(`   ${n}`);
  }
  inputs.push(`Gaz ziemny: ${r.inputs.gasM3 === null ? 'nie podano' : `${fmt(r.inputs.gasM3)} m³ — dane użytkownika`}.`);
  for (const t of inputs) bullet(t);

  // ——— Zakres
  heading('Zakres obliczenia');
  para('Uwzględniono: Scope 1 — CO₂ ze spalania paliw w pojazdach firmy (własnych lub kontrolowanych, np. w leasingu) oraz, jeśli podano, gazu ziemnego; Scope 2 — CO₂ związane z energią elektryczną kupioną z sieci, metodą location-based (średni wskaźnik krajowy). Suma Scope 1 i Scope 2 jest poprawna, bo oba wyniki są w tej samej jednostce (kg CO₂) i obejmują ten sam gaz.', 8.4);
  y += 2;
  font('Inter', 'bold', 9); color(C.navy); ensure(7); doc.text('Poza zakresem obliczenia', M, y, { baseline: 'top' }); y += 5.5;
  for (const t of r.outOfScope) bullet(t, 8.2);

  // ——— Metoda i współczynniki
  heading('Metoda i współczynniki');
  para('Emisja = ilość × współczynnik. Paliwa: litry × gęstość × wartość opałowa (WO) × wskaźnik emisji CO₂ (WE). Gaz ziemny: m³ × wartość opałowa × WE. Energia elektryczna: kWh × wskaźnik KOBiZE dla odbiorców końcowych. Klasyfikacja Scope 1 i Scope 2 według GHG Protocol. Do każdego okresu stosujemy najnowsze opublikowane współczynniki — rok danych podano poniżej.', 8.4);
  y += 2;
  const pl = perLitre('petrol'), dl = perLitre('diesel'), ll = perLitre('lpg'), gm = gasPerM3();
  const factorRows: [string, string, FactorSource, string?][] = [
    ['Energia elektryczna (odbiorca końcowy)', `${fmt(F.electricity.value, 3)} kg CO₂/kWh (553 kg CO₂/MWh)`, F.electricity.source],
    ['Benzyna silnikowa', `WO ${fmt(F.fuels.petrol.ncv, 1)} MJ/kg, WE ${fmt(F.fuels.petrol.ef, 2)} kg CO₂/GJ → ${fmt(pl.co2, 3)} kg CO₂/l`, F.fuels.petrol.source, `Gęstość ${fmt(F.fuels.petrol.density, 4)} kg/l (${F.fuels.petrol.densityNote}, Dz.U. 2024 poz. 1018).`],
    ['Olej napędowy', `WO ${fmt(F.fuels.diesel.ncv, 1)} MJ/kg, WE ${fmt(F.fuels.diesel.ef, 2)} kg CO₂/GJ → ${fmt(dl.co2, 3)} kg CO₂/l`, F.fuels.diesel.source, `Gęstość ${fmt(F.fuels.diesel.density, 4)} kg/l (${F.fuels.diesel.densityNote}, Dz.U. 2024 poz. 1018).`],
    ['Gaz ciekły LPG', `WO ${fmt(F.fuels.lpg.ncv, 1)} MJ/kg, WE ${fmt(F.fuels.lpg.ef, 2)} kg CO₂/GJ → ${fmt(ll.co2, 3)} kg CO₂/l`, F.fuels.lpg.source, `Gęstość ${fmt(F.fuels.lpg.density, 3)} kg/l (karta charakterystyki ORLEN LPG, wersja 1.6).`],
    ['Gaz ziemny wysokometanowy', `WO ${fmt(F.gas.ncvPerM3, 2)} MJ/m³, WE ${fmt(F.gas.ef, 2)} kg CO₂/GJ → ${fmt(gm.co2, 3)} kg CO₂/m³`, F.gas.source],
  ];
  for (const [name, val, src, extra] of factorRows) {
    font('Inter', 'normal', 7.6);
    const block = [
      ...(doc.splitTextToSize(`${src.publisher}: ${src.title}. Gazy: CO₂. Rok danych: ${src.dataYear ?? '—'}. Publikacja: ${pubDate(src.published)}.`, CW - 4) as string[]),
    ];
    const extraLines = extra ? (doc.splitTextToSize(extra, CW - 4) as string[]) : [];
    const urlLines = doc.splitTextToSize(src.url, CW - 4) as string[];
    const h = lh(8.6) + (block.length + extraLines.length + urlLines.length) * lh(7.6) + 4;
    ensure(h);
    font('Inter', 'bold', 8.6); color(C.navy); doc.text(name, M, y, { baseline: 'top' });
    font('Inter', 'normal', 8.6); color(C.ink); doc.text(val, M + CW, y, { baseline: 'top', align: 'right' });
    y += lh(8.6) + 0.5;
    font('Inter', 'normal', 7.6); color(C.muted);
    for (const ln of block) { doc.text(ln, M, y, { baseline: 'top' }); y += lh(7.6); }
    for (const ln of extraLines) { doc.text(ln, M, y, { baseline: 'top' }); y += lh(7.6); }
    color(C.taupe);
    for (const ln of urlLines) { doc.textWithLink(ln, M, y, { url: src.url, baseline: 'top' }); y += lh(7.6); }
    y += 2;
    stroke(C.line); doc.setLineWidth(0.2); doc.line(M, y - 1, M + CW, y - 1);
  }
  if (r.lines.some((l) => l.estimated)) {
    y += 1;
    para(`Tryb szacunkowy floty: przyjęte spalanie to założenie (osobowe: benzyna ${fmt(F.vehicleTypes.car.consumption.petrol, 1)}, ON ${fmt(F.vehicleTypes.car.consumption.diesel, 1)}, LPG ${fmt(F.vehicleTypes.car.consumption.lpg, 1)} l/100 km; dostawcze do 3,5 t: ${fmt(F.vehicleTypes.van.consumption.petrol, 1)} / ${fmt(F.vehicleTypes.van.consumption.diesel, 1)} / ${fmt(F.vehicleTypes.van.consumption.lpg, 1)} l/100 km), chyba że użytkownik podał własne spalanie. Litry z faktur dają dokładniejszy wynik.`, 7.8, C.muted);
  }
  y += 2;
  para('Odniesienia metodyczne: GHG Protocol Corporate Standard i Scope 2 Guidance; dobrowolny standard dla MŚP (VSME) — moduł B3 wymaga m.in. emisji w tCO₂e, czego to zestawienie nie zapewnia (wyłącznie CO₂).', 7.8, C.muted);
  const refs = [
    ...F.frameworks.map((f) => ({ label: f.label, url: f.url })),
    { label: `Gęstość benzyny i oleju napędowego: ${F.fuels.petrol.densitySource.title}`, url: F.fuels.petrol.densitySource.url },
    { label: `Gęstość LPG: ${F.fuels.lpg.densitySource.publisher}, ${F.fuels.lpg.densitySource.title}`, url: F.fuels.lpg.densitySource.url },
  ];
  for (const fw of refs) {
    font('Inter', 'normal', 7.4); color(C.taupe);
    for (const ln of doc.splitTextToSize(`${fw.label}: ${fw.url}`, CW) as string[]) { ensure(lh(7.4)); doc.textWithLink(ln, M, y, { url: fw.url, baseline: 'top' }); y += lh(7.4); }
  }

  // Zastrzeżenie na końcu dokumentu
  y += 4;
  font('Inter', 'bold', 8.6);
  const disc2 = doc.splitTextToSize(DISCLAIMER, CW - 10) as string[];
  if (y + disc2.length * lh(8.6) + 8 <= PAGE_H - FOOT - 4) {
  fill(C.ivory); stroke(C.gold); doc.setLineWidth(0.35); doc.roundedRect(M, y, CW, disc2.length * lh(8.6) + 6, 2, 2, 'FD');
  color(C.navy); disc2.forEach((ln, n) => doc.text(ln, M + 5, y + 3 + n * lh(8.6), { baseline: 'top' }));
  } // brak miejsca: zastrzeżenie jest na 1. stronie i w stopce każdej strony

  // ——— Stopki
  const pages = doc.getNumberOfPages();
  for (let p = 1; p <= pages; p++) {
    doc.setPage(p);
    stroke(C.line); doc.setLineWidth(0.25); doc.line(M, PAGE_H - FOOT + 2, PAGE_W - M, PAGE_H - FOOT + 2);
    font('Inter', 'normal', 7); color(C.muted);
    doc.text('MGT Finance · mgtfinance.eu · wstępne zestawienie na podstawie danych użytkownika — nie stanowi audytu ani certyfikatu', M, PAGE_H - FOOT + 5, { baseline: 'top' });
    doc.text(`Strona ${p} z ${pages}`, PAGE_W - M, PAGE_H - FOOT + 5, { baseline: 'top', align: 'right' });
  }
  doc.setPage(1);
  return doc;
}

/** Ładuje fonty i logo z serwera strony (statyczne pliki) — tylko w przeglądarce. */
export async function loadPdfAssets(): Promise<PdfAssets> {
  const b64 = async (url: string) => {
    const buf = new Uint8Array(await (await fetch(url)).arrayBuffer());
    let s = '';
    for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode(...buf.subarray(i, i + 0x8000));
    return btoa(s);
  };
  const [inter400, inter600, cormorant500, logo] = await Promise.all([
    b64('/fonts/pdf/inter-400.ttf'),
    b64('/fonts/pdf/inter-600.ttf'),
    b64('/fonts/pdf/cormorant-500.ttf'),
    b64('/img/logo-mgt.png').catch(() => null),
  ]);
  return { inter400, inter600, cormorant500, logoPng: logo ? `data:image/png;base64,${logo}` : null };
}
