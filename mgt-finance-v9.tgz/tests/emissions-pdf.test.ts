// Test generatora PDF: dokument powstaje, ma wymagane treści i obsługuje długą nazwę firmy.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { jsPDF } from 'jspdf';
import { buildPdf, DISCLAIMER, fileName, type PdfAssets } from '../src/lib/emissions-pdf.ts';
import { calculate, EMPTY_INPUTS } from '../src/lib/emissions.ts';

const b64 = (p: string) => readFileSync(new URL(`../public/${p}`, import.meta.url)).toString('base64');
const assets: PdfAssets = {
  inter400: b64('fonts/pdf/inter-400.ttf'),
  inter600: b64('fonts/pdf/inter-600.ttf'),
  cormorant500: b64('fonts/pdf/cormorant-500.ttf'),
  logoPng: `data:image/png;base64,${b64('img/logo-mgt.png')}`,
};
const hasPdftotext = (() => { try { execFileSync('pdftotext', ['-v'], { stdio: 'ignore' }); return true; } catch { return false; } })();
const textOf = (pdf: ArrayBuffer) => {
  const dir = mkdtempSync(join(tmpdir(), 'pdf-'));
  const f = join(dir, 'z.pdf');
  writeFileSync(f, Buffer.from(pdf));
  return execFileSync('pdftotext', ['-layout', f, '-'], { encoding: 'utf8' });
};

const result = calculate({
  ...EMPTY_INPUTS,
  company: 'Przedsiębiorstwo Usługowo-Handlowe „Żółta Łódź” Spółka z ograniczoną odpowiedzialnością Spółka Komandytowa — Oddział w Łomży',
  period: 'rok 2025',
  electricityKwh: 12_000,
  litres: { petrol: 1_500, diesel: 2_000, lpg: null },
  gasM3: 1_000,
});

test('PDF: poprawny dokument A4 z co najmniej dwiema stronami', () => {
  const doc = buildPdf(jsPDF, result, assets, new Date('2026-10-03T12:00:00'));
  const out = doc.output('arraybuffer');
  assert.equal(Buffer.from(out).subarray(0, 5).toString(), '%PDF-');
  assert.ok(doc.getNumberOfPages() >= 2);
  const size = doc.internal.pageSize;
  assert.ok(Math.abs(size.getWidth() - 210) < 0.5 && Math.abs(size.getHeight() - 297) < 0.5);
});

test('PDF: zawiera tytuł, zastrzeżenie, Scope 1 i 2, jednostki, źródła i polskie znaki', { skip: !hasPdftotext }, () => {
  const t = textOf(buildPdf(jsPDF, result, assets).output('arraybuffer')).replace(/\s+/g, ' ');
  for (const s of [
    'Wstępne zestawienie energii i wybranych emisji',
    'Żółta Łódź',
    'rok 2025',
    'Scope 1', 'Scope 2', 't CO₂', 'MWh',
    '17,47 t CO₂',
    'Poza zakresem obliczenia',
    'kobize.pl',
    'Wygenerowano',
  ]) assert.ok(t.includes(s), `brak: ${s}`);
  assert.ok(t.includes(DISCLAIMER.slice(0, 60)), 'brak zastrzeżenia');
});

test('PDF: tryb szacunkowy jest opisany jako szacunek', { skip: !hasPdftotext }, () => {
  const r = calculate({ ...EMPTY_INPUTS, period: '2025', fleetMode: 'estimate', groups: [{ type: 'car', fuel: 'diesel', count: 3, kmPerVehicle: 25_000, consumption: null }] });
  const t = textOf(buildPdf(jsPDF, r, assets).output('arraybuffer')).replace(/\s+/g, ' ');
  assert.ok(t.includes('tryb szacunkowy'));
  assert.ok(t.includes('przyjęte spalanie'));
});

test('Nazwa pliku bez polskich znaków i spacji', () => {
  assert.equal(fileName(calculate({ ...EMPTY_INPUTS, company: 'Łąka Sp. z o.o.', period: 'rok 2025' }), new Date('2026-10-03')), 'zestawienie-emisji-laka-sp-z-o-o-rok-2025.pdf');
});
