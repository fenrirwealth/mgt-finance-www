import { defineConfig } from 'astro/config';
import node from '@astrojs/node';
import sitemap from '@astrojs/sitemap';

export default defineConfig({
  site: 'https://mgtfinance.eu',
  output: 'server',
  trailingSlash: 'ignore',
  adapter: node({ mode: 'standalone' }),
  integrations: [sitemap({ filter: (p) => !p.includes('/api/') })],
  server: { host: true, port: 4321 },
  build: { inlineStylesheets: 'auto' },
});
