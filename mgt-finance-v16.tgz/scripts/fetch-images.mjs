// Pobiera zdjęcia ze starej strony mgtfinance.pl i zapisuje je w formacie WebP.
import sharp from 'sharp';
import { writeFile } from 'node:fs/promises';
const B = 'https://mgtfinance.pl/wp-content/uploads/2024/';
const MAP = {
  'biuro-hero': '09/mgt-finance-biuro.webp', zespol: '09/dfg34tfsdgfsdg.webp', spotkanie: '09/aef8ed38ccbaf272ceeda9a714cdd927.webp',
  temida: '08/lady-justice-lady-justice-statue-on-table-law-them-E2QXDPE.jpg', ksiegowa: '09/ksiegowa.webp', 'obsluga-kpir': '09/obsluga-kpir.webp',
  kpir: '09/kpir.jpg', 'doradztwo-lomza': '09/doradztwo-podatkowe-lomza.webp', doradztwo: '09/doradztwo-podatkowe-1.webp',
  's-spolki': '09/Pelna-ksiegowosc-spolek.webp', 's-kpir': '09/Ksiega-przychodow-i-rozchodow-z-rozrachunkami.webp',
  's-kadry': '09/Kadry-i-place-w-rozliczeniu-za-osobe.webp', 's-podatki': '09/Doradztwo-podatkowe.webp',
  's-wierzytelnosci': '09/Zarzadzanie-wierzytelnosciami-poprzez-kontrolowanie-platnosci.webp',
  's-rejestracja': '09/Rejestracja-podmiotow-gospodarczych.webp', 's-kancelaria': '09/Stala-wspolpraca-z-kancelaria-prawna.webp',
};
for (const [name, path] of Object.entries(MAP)) {
  const r = await fetch(B + path);
  if (!r.ok) throw new Error(`${path}: ${r.status}`);
  const buf = Buffer.from(await r.arrayBuffer());
  await sharp(buf).resize({ width: 1920, withoutEnlargement: true }).webp({ quality: name.startsWith('s-') ? 88 : 82 }).toFile(`public/img/${name}.webp`);
  if (!name.startsWith('s-')) await sharp(buf).resize({ width: 640, withoutEnlargement: true }).webp({ quality: 78 }).toFile(`public/img/${name}-640.webp`);
  console.log('ok', name);
}
const logo = await fetch(B + '08/mgt.png');
await writeFile('public/img/mgt.png', Buffer.from(await logo.arrayBuffer()));
console.log('ok logo');

// Original logo files: copied byte-for-byte, without conversion or recoloring.
for (const [name, source] of [['logo-mgt.png','logo-mgt.png'],['logo-mgt-footer.png','logo-mgt-.png']]) {
 const response=await fetch(B+'08/'+source);
 if (!response.ok) throw new Error('Original logo download failed: '+response.status);
 await writeFile('public/img/'+name,Buffer.from(await response.arrayBuffer()));
}
const ogText=Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630"><rect width="735" height="630" fill="#fbf8f4"/><text x="80" y="295" font-family="Arial,sans-serif" font-size="58" fill="#1D2041">Księgowość, która</text><text x="80" y="365" font-family="Arial,sans-serif" font-size="58" fill="#907365">daje Ci spokój.</text><text x="82" y="470" font-family="Arial,sans-serif" font-size="23" fill="#626779">Biuro rachunkowe · Łomża i cała Polska</text><text x="82" y="520" font-family="Arial,sans-serif" font-size="25" fill="#1D2041">mgtfinance.eu · +48 664 923 274</text></svg>`);
const ogBg=await sharp('public/img/finance-editorial.avif').resize(1200,630,{fit:'cover',position:'right'}).toBuffer();
await sharp(ogBg).composite([{input:ogText},{input:'public/img/logo-mgt.png',left:80,top:85}]).jpeg({quality:84}).toFile('public/img/og.jpg');
console.log('ok original branding and og');
