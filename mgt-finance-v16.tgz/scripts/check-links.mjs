// Sprawdza linki zewnętrzne z sekcji e-Urzędy (src/data/rates.js). Uruchom: node scripts/check-links.mjs
// Uwaga: część serwisów (np. wyszukiwarka KRS) blokuje zapytania automatyczne kodem 403, choć działa w przeglądarce.
import { readFileSync } from 'node:fs';
const src = readFileSync(new URL('../src/data/rates.js', import.meta.url), 'utf8');
const urls = [...new Set([...src.matchAll(/u: '(https?:\/\/[^']+)'/g)].map((m) => m[1]))];
let bad = 0;
for (const u of urls) {
  try {
    const r = await fetch(u, { redirect: 'follow', headers: { 'user-agent': 'Mozilla/5.0 (link-check mgtfinance.eu)' }, signal: AbortSignal.timeout(20000) });
    const note = r.status === 403 ? ' (możliwa blokada botów — sprawdź w przeglądarce)' : '';
    if (!r.ok) bad++;
    console.log(`${r.ok ? 'OK ' : 'ERR'} ${r.status} ${u}${note}`);
  } catch (e) {
    bad++;
    console.log(`ERR --- ${u} (${e.cause?.code || e.name})`);
  }
}
console.log(`\n${urls.length} linków, problemów: ${bad}`);
