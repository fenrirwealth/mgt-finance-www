// Testy zestawienia energii i emisji — przykłady policzone ręcznie. Uruchom: pnpm test
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { calculate, EMPTY_INPUTS, parseAmount, perLitre, gasPerM3, summaryText, type EmissionInputs } from '../src/lib/emissions.ts';
import { EMISSION_FACTORS as F } from '../src/data/emission-factors.ts';

const close = (a: number, e: number, tol = 0.01, msg = '') => assert.ok(Math.abs(a - e) < tol, `${msg} oczekiwano ${e}, jest ${a}`);
const base = (o: Partial<EmissionInputs> = {}): EmissionInputs => ({ ...EMPTY_INPUTS, litres: { ...EMPTY_INPUTS.litres }, groups: [], ...o });

test('Współczynniki pochodne — ręcznie z danych KOBiZE i gęstości', () => {
  close(perLitre('petrol').co2, (0.7475 * 44.3 * 69.3) / 1000, 1e-9); // 2,2948 kg CO₂/l
  close(perLitre('diesel').co2, (0.8325 * 43.0 * 74.1) / 1000, 1e-9); // 2,6526
  close(perLitre('lpg').co2, (0.549 * 47.3 * 63.1) / 1000, 1e-9); // 1,6386
  close(gasPerM3().co2, (37.17 * 56.18) / 1000, 1e-9); // 2,0882 kg CO₂/m³
  close(perLitre('diesel').kwh, (0.8325 * 43.0) / 3.6, 1e-9); // 9,944 kWh/l
  assert.equal(F.electricity.value, 0.553);
  assert.equal(F.electricity.gases, 'CO₂');
  assert.equal(F.electricity.source.dataYear, 2024);
});

test('Przykład A: prąd + benzyna + ON + gaz — Scope 1, Scope 2, suma, energia', () => {
  const r = calculate(base({ electricityKwh: 12_000, litres: { petrol: 1_500, diesel: 2_000, lpg: null }, gasM3: 1_000 }));
  close(r.scope2Kg, 6_636); // 12 000 × 0,553
  close(r.lines.find((l) => l.key === 'fuel-petrol')!.co2Kg, 3_442.23);
  close(r.lines.find((l) => l.key === 'fuel-diesel')!.co2Kg, 5_305.19);
  close(r.lines.find((l) => l.key === 'gas')!.co2Kg, 2_088.21);
  close(r.scope1Kg, 10_835.63);
  close(r.totalKg, 17_471.63);
  close(r.energy.electricityKwh, 12_000);
  close(r.energy.fuelsKwh, 13_797.60 + 19_887.5 + 10_325, 0.05);
  close(r.energy.totalKwh / 1000, 56.0101, 1e-3); // MWh
  assert.equal(r.errors, 0);
  assert.equal(r.lines.every((l) => !l.estimated), true);
});

test('Scope: prąd to Scope 2, paliwa i gaz to Scope 1', () => {
  const r = calculate(base({ electricityKwh: 1, litres: { petrol: 1, diesel: 1, lpg: 1 }, gasM3: 1 }));
  for (const l of r.lines) assert.equal(l.scope, l.key === 'electricity' ? 2 : 1, l.key);
});

test('Tryb szacunkowy: liczba pojazdów × przebieg × przyjęte spalanie, oznaczony jako szacunek', () => {
  const r = calculate(base({ fleetMode: 'estimate', groups: [{ type: 'car', fuel: 'diesel', count: 3, kmPerVehicle: 25_000, consumption: null }] }));
  const l = r.lines[0];
  close(l.amount, 4_500); // 3 × 25 000 × 6,0 / 100
  close(l.co2Kg, 4_500 * 2.65259475);
  assert.equal(l.estimated, true);
  assert.ok(r.estimatedNotes[0].includes('przyjęte spalanie'));
});

test('Tryb szacunkowy: spalanie podane przez użytkownika zastępuje założenie', () => {
  const r = calculate(base({ fleetMode: 'estimate', groups: [{ type: 'van', fuel: 'petrol', count: 2, kmPerVehicle: 10_000, consumption: 12.5 }] }));
  close(r.lines[0].amount, 2_500);
  assert.ok(r.lines[0].source.includes('podane przez użytkownika'));
});

test('Sama liczba aut bez przebiegu nie daje wyniku — błąd i pozycja poza zakresem', () => {
  const r = calculate(base({ fleetMode: 'estimate', groups: [{ type: 'car', fuel: 'petrol', count: 5, kmPerVehicle: null, consumption: null }] }));
  assert.equal(r.lines.length, 0);
  assert.equal(r.hasData, false);
  assert.ok(r.issues.some((x) => x.field === 'groups.0.kmPerVehicle' && x.level === 'error'));
  assert.ok(r.outOfScope.some((x) => x.includes('brak przebiegu')));
});

test('W trybie litrów grupy pojazdów są ignorowane (i odwrotnie)', () => {
  const groups = [{ type: 'car' as const, fuel: 'diesel' as const, count: 3, kmPerVehicle: 25_000, consumption: null }];
  assert.equal(calculate(base({ litres: { petrol: null, diesel: 100, lpg: null }, groups })).lines.length, 1);
  assert.equal(calculate(base({ fleetMode: 'estimate', litres: { petrol: 999, diesel: 999, lpg: 999 }, groups })).lines[0].estimated, true);
});

test('Puste pola to „nie podano”, zero to podana wartość zero', () => {
  const empty = calculate(base());
  assert.equal(empty.hasData, false);
  assert.equal(empty.totalKg, 0);
  const zero = calculate(base({ electricityKwh: 0 }));
  assert.equal(zero.hasData, true);
  assert.equal(zero.lines[0].co2Kg, 0);
});

test('Nielogiczne wartości: ujemne, tekst, nierealne spalanie, przebieg i liczba pojazdów', () => {
  const r = calculate(base({ electricityKwh: -5, gasM3: Number.NaN }));
  assert.equal(r.errors, 2);
  assert.equal(r.lines.length, 0);
  const g = (o: object) => calculate(base({ fleetMode: 'estimate', groups: [{ type: 'car', fuel: 'petrol', count: 1, kmPerVehicle: 10_000, consumption: null, ...o }] }));
  assert.equal(g({ consumption: 60 }).errors, 1);
  assert.equal(g({ consumption: 1 }).errors, 1);
  assert.equal(g({ kmPerVehicle: 500_000 }).errors, 1);
  assert.equal(g({ count: 2.5 }).errors, 1);
  assert.equal(g({ count: 0 }).lines.length, 0); // zero pojazdów — nic do policzenia, bez błędu
  assert.equal(g({ count: 0 }).errors, 0);
});

test('Ostrzeżenie przy podejrzanie dużej wartości (np. Wh zamiast kWh) — wynik nadal liczony', () => {
  const r = calculate(base({ electricityKwh: 80_000_000 }));
  assert.ok(r.issues.some((x) => x.level === 'warning'));
  assert.equal(r.errors, 0);
  close(r.scope2Kg, 44_240_000);
});

test('„Zielona” energia nie zeruje Scope 2 (location-based) i trafia do „Poza zakresem”', () => {
  const r = calculate(base({ electricityKwh: 10_000, greenClaim: true }));
  close(r.scope2Kg, 5_530);
  assert.ok(r.outOfScope[0].includes('market-based'));
});

test('Inne paliwa bez współczynnika — oznaczone jako niepoliczone', () => {
  const r = calculate(base({ otherFuels: true, litres: { petrol: 100, diesel: null, lpg: null } }));
  assert.ok(r.outOfScope.some((x) => x.includes('nie ma dla nich współczynników')));
});

test('Stała lista pozycji poza zakresem zawiera ciepło sieciowe, CH₄/N₂O i Scope 3', () => {
  const t = calculate(base()).outOfScope.join(' ');
  for (const s of ['Ciepło sieciowe', 'N₂O', 'Scope 3', 'market-based']) assert.ok(t.includes(s), s);
});

test('parseAmount: polski zapis liczb, puste pole, błędny tekst', () => {
  assert.equal(parseAmount('12 000,5'), 12000.5);
  assert.equal(parseAmount('12 000'), 12000);
  assert.equal(parseAmount(''), null);
  assert.equal(parseAmount('  '), null);
  assert.ok(Number.isNaN(parseAmount('12a') as number));
  assert.equal(parseAmount('-3'), -3);
});

test('Długa nazwa firmy i okres są przycinane; podsumowanie bez HTML', () => {
  const r = calculate(base({ company: '  A'.repeat(200), period: 'rok 2025', electricityKwh: 1000 }));
  assert.ok(r.inputs.company.length <= 160);
  const t = summaryText(r);
  assert.ok(t.includes('Scope 2 (location-based): 0,55 t CO₂'));
  assert.ok(!/[<>]/.test(t));
});
