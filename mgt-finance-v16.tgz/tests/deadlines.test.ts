// Testy kalendarza podatkowego: daty, profile, przypomnienia, ICS/VALARM, token subskrypcji.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  deadlinesForYear, forProfile, matches, reasons, reminderDates, normalizeAlarms, toICS, alarmTrigger,
  profileToken, parseToken, workday, holidays, upcoming, subscribeLinks,
} from '../src/lib/deadlines.js';
import { addDays, diffDays, todayISO, formatDateList, plural, isISODate, lastDayOfMonth } from '../src/lib/dates.js';
import { RULES, PROFILE } from '../src/data/deadline-rules.js';

const y26 = deadlinesForYear(2026);

test('TEST 2: termin 15.10.2026, przypomnienie 2 dni wcześniej → 13.10.2026', () => {
  assert.deepEqual(reminderDates('2026-10-15', [2]), ['2026-10-13']);
});
test('TEST 3: termin 01.01.2027, 2 dni wcześniej → 30.12.2026 (zmiana roku)', () => {
  assert.deepEqual(reminderDates('2027-01-01', [2]), ['2026-12-30']);
});
test('Daty: koniec miesiąca, luty, lata przestępne, zmiana czasu', () => {
  assert.equal(addDays('2026-03-01', -1), '2026-02-28');
  assert.equal(addDays('2028-03-01', -1), '2028-02-29');
  assert.equal(lastDayOfMonth(2028, 1), 29);
  assert.equal(addDays('2026-03-31', 1), '2026-04-01');
  assert.equal(diffDays('2026-10-24', '2026-10-26'), 2); // przejście na czas zimowy 25.10
  assert.equal(diffDays('2026-03-28', '2026-03-30'), 2); // przejście na czas letni 29.03
  assert.equal(isISODate('2026-02-30'), false);
});
test('„Dzisiaj” liczone w strefie Europe/Warsaw', () => {
  assert.equal(todayISO(new Date('2026-10-14T22:30:00Z')), '2026-10-15'); // 00:30 w Polsce
  assert.equal(todayISO(new Date('2026-12-31T23:30:00Z')), '2027-01-01');
});
test('Dwa domyślne przypomnienia i normalizacja', () => {
  assert.deepEqual(reminderDates('2026-10-15', [1, 3]), ['2026-10-12', '2026-10-14']);
  assert.deepEqual(normalizeAlarms(['3', 1, 1, 9, -2]), [3, 1]);
});
test('Przesunięcie na dzień roboczy (sobota, niedziela, święta, Wigilia od 2025)', () => {
  assert.equal(workday('2026-11-15'), '2026-11-16'); // niedziela → poniedziałek
  assert.equal(workday('2026-08-15'), '2026-08-17'); // sobota + święto
  assert.ok(holidays(2026).has('2026-12-24'));
  assert.ok(holidays(2026).has('2026-04-06')); // Poniedziałek Wielkanocny 2026
  const e = y26.find((x) => x.id === 'zus-15-2026-11')!;
  assert.equal(e.date, '2026-11-16');
  assert.equal(e.shifted, true);
  assert.equal(e.nominal, '2026-11-15');
});
test('TEST 1: profil „Spółka z o.o.” widzi tylko terminy spółki', () => {
  const ev = forProfile(y26, ['spolka']);
  assert.ok(ev.length > 0);
  for (const e of ev) assert.ok(e.appliesTo.some((alt) => alt.length === 1 && alt[0] === 'spolka'), e.id);
  const rules = new Set(ev.map((e) => e.rule));
  for (const r of ['zus-20', 'pit-mies', 'pit-roczny', 'jpk-v7', 'pit-platnik', 'vat-ue']) assert.ok(!rules.has(r), r);
  for (const r of ['zus-15', 'cit-zal', 'cit-8', 'sf-krs']) assert.ok(rules.has(r), r);
});
test('Profil złożony: spółka + VAT + pracownicy; „Dlaczego widzisz ten termin?”', () => {
  const p = ['spolka', 'vat', 'pracodawca'];
  const rules = new Set(forProfile(y26, p).map((e) => e.rule));
  for (const r of ['zus-15', 'cit-zal', 'jpk-v7', 'pit-platnik', 'pit-4r']) assert.ok(rules.has(r), r);
  assert.ok(!rules.has('zus-20'));
  const zus = y26.find((e) => e.id === 'zus-15-2026-10')!;
  assert.deepEqual(reasons(zus, p), ['Spółka z o.o.']);
  assert.equal(matches(zus, ['jdg']), false);
});
test('TEST 10: brak profilu → brak terminów', () => {
  assert.deepEqual(forProfile(y26, []), []);
});
test('Najbliższe terminy: 7 dni od 13.10.2026 dla spółki', () => {
  const list = upcoming(forProfile([...y26, ...deadlinesForYear(2027)], ['spolka']), '2026-10-13', 7);
  assert.deepEqual(list.map((e) => e.date), ['2026-10-15', '2026-10-20']);
});
test('Każda reguła ma źródło i daty w poprawnym formacie; dane nie zawierają zmyślonych weryfikacji', () => {
  for (const r of RULES) {
    assert.ok(r.source && r.source.name, r.id);
    for (const k of ['verifiedAt', 'updatedAt'] as const) assert.ok(r[k] === null || isISODate(r[k]), `${r.id}.${k}`);
    for (const alt of r.appliesTo) for (const f of alt) assert.ok(PROFILE.some((p) => p.key === f), `${r.id}: ${f}`);
  }
  const ids = y26.map((e) => e.id);
  assert.equal(new Set(ids).size, ids.length, 'UID muszą być unikalne');
});
test('TEST 5: ICS zawiera poprawne VALARM (dwa alarmy), daty całodniowe i zawinięte linie', () => {
  const ev = y26.filter((e) => e.id === 'zus-15-2026-10');
  const ics = toICS(ev, { alarms: [3, 1], now: new Date('2026-10-04T10:00:00Z') });
  assert.equal((ics.match(/BEGIN:VALARM/g) || []).length, 2);
  assert.ok(ics.includes('TRIGGER:-P2DT15H')); // 3 dni wcześniej o 9:00
  assert.ok(ics.includes('TRIGGER:-PT15H')); // 1 dzień wcześniej o 9:00
  assert.ok(ics.includes('ACTION:DISPLAY'));
  assert.ok(ics.includes('DTSTART;VALUE=DATE:20261015'));
  assert.ok(ics.includes('DTEND;VALUE=DATE:20261016'));
  assert.ok(ics.includes('UID:zus-15-2026-10@mgtfinance.eu'));
  for (const line of ics.split('\r\n')) assert.ok(new TextEncoder().encode(line).length <= 75, line);
  assert.ok(ics.endsWith('END:VCALENDAR\r\n'));
});
test('Wyzwalacz alarmu: 2 dni wcześniej o 9:00 = -P1DT15H', () => {
  assert.equal(alarmTrigger(2), '-P1DT15H');
  assert.equal(alarmTrigger(7), '-P6DT15H');
  assert.equal(alarmTrigger(1), '-PT15H');
});
test('Token subskrypcji: kanoniczny, ograniczony, bez dowolnych parametrów', () => {
  assert.equal(profileToken(['vat', 'spolka', 'pracodawca'], [1, 3]), 'spv-31');
  assert.deepEqual(parseToken('spv-31')?.profile, ['spolka', 'pracodawca', 'vat']);
  assert.equal(parseToken('vps-13')?.isCanonical, false);
  assert.equal(parseToken('vps-13')?.canonical, 'spv-31');
  for (const bad of ['', 'x-1', 'spv-4', 'spv', '../etc', 'spv-31.ics', 'SPV-31']) assert.equal(parseToken(bad), null, bad);
  assert.equal(profileToken([], [1]), null);
  const links = subscribeLinks('https://mgtfinance.eu/kalendarz/spv-31.ics');
  assert.equal(links.apple, 'webcal://mgtfinance.eu/kalendarz/spv-31.ics');
  assert.ok(links.google.startsWith('https://calendar.google.com/calendar/r?cid=webcal%3A%2F%2F'));
});
test('Formatowanie: lista dat przypomnień i odmiana', () => {
  assert.equal(formatDateList(['2026-10-14', '2026-10-12']), '12 i 14 października 2026');
  assert.equal(formatDateList(['2026-12-30', '2027-01-01']), '30 grudnia 2026 i 1 stycznia 2027');
  assert.equal(plural(1, 'termin', 'terminy', 'terminów'), 'termin');
  assert.equal(plural(3, 'termin', 'terminy', 'terminów'), 'terminy');
  assert.equal(plural(12, 'termin', 'terminy', 'terminów'), 'terminów');
  assert.equal(plural(28, 'termin', 'terminy', 'terminów'), 'terminów');
});
