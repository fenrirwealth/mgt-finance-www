import { test } from 'node:test';
import assert from 'node:assert/strict';
import { daysUntil, daysWord, countdownText } from '../src/lib/countdown.ts';

test('4 października → 15 października = 11 dni, cyframi arabskimi', () => {
  assert.equal(daysUntil('2026-10-15', '2026-10-04'), 11);
  assert.equal(countdownText(11), '11 dni do najbliższego terminu');
  assert.ok(!/[IVXLC]{2,}/.test(countdownText(11)));
});
test('Zmiana czasu (koniec października) nie przesuwa wyniku', () => {
  assert.equal(daysUntil('2026-11-02', '2026-10-24'), 9);
  assert.equal(daysUntil('2027-04-01', '2027-03-27'), 5);
});
test('Odmiana i przypadki brzegowe', () => {
  assert.equal(daysWord(1), 'dzień');
  assert.equal(daysWord(2), 'dni');
  assert.equal(countdownText(0), 'Dziś upływa najbliższy termin');
  assert.equal(daysUntil('2026-10-04', '2026-10-04'), 0);
  assert.equal(daysUntil('2026-10-01', '2026-10-04'), 0);
  assert.equal(daysUntil('2027-01-05', '2026-12-28'), 8);
});
