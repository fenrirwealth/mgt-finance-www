// Testy rachunkowe symulatora. Uruchom: node --test tests/
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { compare, companyClassic, companyEstonian, jdgLinear, summaryText, type Inputs } from '../src/lib/business-forms.ts';

const close = (actual: number, expected: number, msg?: string) =>
  assert.ok(Math.abs(actual - expected) < 0.01, `${msg ?? ''} oczekiwano ${expected}, jest ${actual}`);

// Przykład bazowy: 60 000 zł przychodu, 15 000 zł kosztów miesięcznie, jeden wspólnik, pełna wypłata.
const A: Inputs = {
  revenue: 60_000,
  costs: 15_000,
  payout: 1,
  jdgZus: 'full',
  sickness: true,
  partners: 1,
  fromTransformation: false,
  estonianStatus: 'yes',
  serviceJdg: 249,
  serviceCompany: 500,
  serviceCompanyOther: 0,
};
const ZUS_YEAR = 12 * 1926.76; // 23 121,12
const HEALTH_MIN_YEAR = 12 * 432.54; // 5 190,48

test('JDG liniowy — przykład policzony ręcznie', () => {
  const s = jdgLinear(A);
  // zysk 720 000 − 180 000 − 2 988 = 537 012; dochód po ZUS 513 890,88
  close(s.profit, 537_012);
  close(s.social, ZUS_YEAR);
  close(s.health, 0.049 * 513_890.88); // 25 180,65
  close(s.taxLines[0].value, 0.19 * (513_890.88 - 14_100)); // 94 960,27 — odliczenie zdrowotnej do limitu 14 100
  close(s.toOwner, 393_749.96);
  assert.equal(s.retained, 0);
});

test('Spółka, klasyczny CIT 9% — pełna wypłata', () => {
  const s = companyClassic(A);
  // zysk 720 000 − 180 000 − 6 000 = 534 000; CIT 9% = 48 060; dywidenda 485 940; PIT 92 328,60
  close(s.profit, 534_000);
  close(s.taxLines[0].value, 48_060);
  close(s.taxLines[1].value, 92_328.6);
  close(s.toOwner, 485_940 - 92_328.6 - ZUS_YEAR - HEALTH_MIN_YEAR); // 365 299,80
  close(s.retained, 0);
});

test('Spółka, estoński CIT — ryczałt przy wypłacie, odliczenie 90%', () => {
  const s = companyEstonian(A);
  const D = 534_000 / 1.1; // 485 454,55 — wypłata i ryczałt mieszczą się w zysku
  close(s.taxLines[0].value, 0.1 * D); // 48 545,45
  close(s.taxLines[1].value, 0.19 * D - 0.9 * 0.1 * D); // 48 545,45
  close(s.taxes / s.profit, 0.2 / 1.1); // ok. 18,18% zysku przed opodatkowaniem
  close(s.toOwner, D - 0.1 * D - ZUS_YEAR - HEALTH_MIN_YEAR); // 408 597,49
  close(s.retained, 0);
  assert.equal(s.approximate, false);
});

test('Zerowy dochód — brak podatku, składki obowiązują', () => {
  const i = { ...A, revenue: 10_000, costs: 9_751 }; // JDG: 12 × (10 000 − 9 751 − 249) = 0
  const j = jdgLinear(i);
  close(j.profit, 0);
  close(j.taxes, 0);
  close(j.health, HEALTH_MIN_YEAR);
  close(j.toOwner, -(ZUS_YEAR + HEALTH_MIN_YEAR));
  const c = companyClassic(i); // spółka: 12 × (10 000 − 9 751 − 500) = −3 012
  close(c.taxes, 0);
  close(c.retained, -3_012);
  close(c.toOwner, -(ZUS_YEAR + HEALTH_MIN_YEAR));
});

test('Strata — żaden scenariusz nie płaci podatku dochodowego', () => {
  const r = compare({ ...A, revenue: 5_000, costs: 20_000 });
  for (const s of r.scenarios) {
    close(s.taxes, 0, s.key);
    assert.ok(s.toOwner < 0, `${s.key}: wynik właściciela ujemny przez składki`);
  }
  close(r.scenarios[2].retained, r.scenarios[2].profit);
});

test('Zysk zatrzymany (50%) — nie wchodzi do kwoty dla właściciela', () => {
  const i = { ...A, payout: 0.5 };
  const c = companyClassic(i);
  close(c.taxLines[1].value, 0.19 * 242_970);
  close(c.retained, 242_970); // po CIT
  close(c.toOwner, 242_970 - 46_164.3 - ZUS_YEAR - HEALTH_MIN_YEAR);
  const e = companyEstonian(i);
  close(e.retained, 267_000); // połowa zysku, jeszcze bez ryczałtu
  const D = (0.5 * 534_000) / 1.1;
  close(e.taxes, 0.1 * D + (0.19 * D - 0.09 * D));
  close(e.toOwner, D - 0.1 * D - ZUS_YEAR - HEALTH_MIN_YEAR);
});

test('Brak wypłaty — estoński CIT nie płaci ryczałtu, klasyczny płaci CIT', () => {
  const i = { ...A, payout: 0 };
  const e = companyEstonian(i);
  close(e.taxes, 0);
  close(e.retained, 534_000);
  const c = companyClassic(i);
  close(c.taxes, 48_060);
  close(c.retained, 485_940);
  close(c.toOwner, -(ZUS_YEAR + HEALTH_MIN_YEAR));
});

test('Brak kwalifikacji do 9% CIT po przekształceniu JDG — stawka 19%', () => {
  const c = companyClassic({ ...A, fromTransformation: true });
  close(c.taxLines[0].value, 0.19 * 534_000);
  close(c.toOwner, 432_540 - 0.19 * 432_540 - ZUS_YEAR - HEALTH_MIN_YEAR);
  assert.ok(c.notes.some((n) => n.includes('przekształcenia')));
});

test('Próg małego podatnika — powyżej limitu ryczałt 20% i odliczenie 70%, CIT 19%', () => {
  // limit 8 517 000 zł brutto ⇒ ok. 577 032 zł netto miesięcznie
  const below = compare({ ...A, revenue: 577_000, costs: 300_000 });
  assert.equal(below.smallTaxpayer, true);
  assert.equal(below.reducedCit, true);
  close(below.estonianRate, 0.1);
  const above = compare({ ...A, revenue: 578_000, costs: 300_000 });
  assert.equal(above.smallTaxpayer, false);
  assert.equal(above.reducedCit, false);
  close(above.estonianRate, 0.2);
  const e = above.scenarios[2];
  const D = e.profit / 1.2;
  close(e.taxLines[0].value, 0.2 * D);
  close(e.taxLines[1].value, 0.19 * D - 0.7 * 0.2 * D); // 5% wypłaty
  const c = above.scenarios[1];
  close(c.taxLines[0].value, 0.19 * c.profit);
});

test('Danina solidarnościowa w JDG powyżej 1 mln zł dochodu', () => {
  const s = jdgLinear({ ...A, revenue: 150_000, costs: 0 });
  const income = 12 * (150_000 - 249) - ZUS_YEAR; // 1 773 890,88
  close(s.taxLines[1].value, 0.04 * (income - 1_000_000)); // 30 955,64
});

test('Składka zdrowotna minimalna i odliczenie poniżej limitu', () => {
  const s = jdgLinear({ ...A, revenue: 8_000, costs: 0 });
  const income = 12 * (8_000 - 249) - ZUS_YEAR; // 69 890,88
  close(s.health, HEALTH_MIN_YEAR); // 4,9% × dochód < minimum
  close(s.taxLines[0].value, 0.19 * (income - HEALTH_MIN_YEAR));
});

test('Dwóch wspólników — brak ZUS wspólnika, JDG oznaczone jako orientacyjne', () => {
  const r = compare({ ...A, partners: 2 });
  close(r.scenarios[1].social + r.scenarios[1].health, 0);
  close(r.scenarios[2].social + r.scenarios[2].health, 0);
  assert.equal(r.scenarios[0].approximate, true);
});

test('Estoński CIT bez spełnienia warunków jest oznaczony jako niedostępny', () => {
  assert.equal(companyEstonian({ ...A, estonianStatus: 'no' }).unavailable, true);
  assert.equal(companyEstonian({ ...A, estonianStatus: 'unknown' }).approximate, true);
});

test('Preferencyjny ZUS i ulga na start w JDG', () => {
  close(jdgLinear({ ...A, jdgZus: 'pref', sickness: false }).social, 12 * (281.44 + 115.34 + 24.08));
  close(jdgLinear({ ...A, jdgZus: 'start' }).social, 0);
});

test('Dane wejściowe spoza zakresu są ograniczane', () => {
  const r = compare({ ...A, revenue: -100, costs: Number.NaN, payout: 5 });
  assert.equal(r.inputs.revenue, 0);
  assert.equal(r.inputs.costs, 0);
  assert.equal(r.inputs.payout, 1);
});

test('Podsumowanie do formularza zawiera wszystkie scenariusze i nie zawiera HTML', () => {
  const t = summaryText(compare(A), 'year');
  assert.ok(t.includes('JDG — podatek liniowy'));
  assert.ok(t.includes('klasyczny CIT'));
  assert.ok(t.includes('estoński CIT'));
  assert.ok(!/[<>]/.test(t));
});
