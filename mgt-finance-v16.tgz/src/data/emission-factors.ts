// Współczynniki do „Wstępnego zestawienia energii i wybranych emisji”.
// Wersjonowany moduł danych: aktualizuj wartości i metadane tutaj (zwykle raz w roku, po publikacjach KOBiZE
// w grudniu), bez zmian w interfejsie. Logika: src/lib/emissions.ts. Każdy współczynnik ma: wartość, jednostkę,
// uwzględnione gazy, rok danych, datę publikacji i źródło.

export type FactorSource = {
  publisher: string;
  title: string;
  dataYear: number | null;
  published: string; // data publikacji, ISO lub opis
  url: string;
};

export type FuelKey = 'petrol' | 'diesel' | 'lpg';

const KOBIZE_FUELS: FactorSource = {
  publisher: 'KOBiZE',
  title: 'Wartości opałowe (WO) i wskaźniki emisji CO₂ (WE) w roku 2023 do raportowania w ramach Systemu Handlu Uprawnieniami do Emisji za rok 2026',
  dataYear: 2023,
  published: '2025-12-16',
  url: 'https://www.kobize.pl/uploads/materialy/materialy_do_pobrania/aktualnosci/2025/135.WO_i_WE_do_monitorowania_ETS_2026.pdf',
};

const FUEL_QUALITY_REG: FactorSource = {
  publisher: 'Minister Klimatu i Środowiska',
  title: 'Rozporządzenie z 26 czerwca 2024 r. w sprawie wymagań jakościowych dla paliw ciekłych (Dz.U. 2024 poz. 1018) — gęstość w 15°C',
  dataYear: null,
  published: '2024-07-10',
  url: 'https://isap.sejm.gov.pl/isap.nsf/download.xsp/WDU20240001018/O/D20241018.pdf',
};

const LPG_SDS: FactorSource = {
  publisher: 'ORLEN',
  title: 'Karta charakterystyki LPG (propan-butan), wersja 1.6 — gęstość ok. 549 kg/m³ w 15,6°C',
  dataYear: null,
  published: '2023-07-03',
  url: 'https://myorlen.pl/documents/10184/4420713/LPG_OWZG+ver.+1.6+PL.pdf/5e0e40cc-9b37-471d-af5b-7a2d71999711',
};

export const EMISSION_FACTORS = {
  version: '2026.1',
  verifiedOn: '2026-10-03',

  electricity: {
    label: 'Energia elektryczna z sieci',
    value: 0.553,
    unit: 'kg CO₂/kWh',
    gases: 'CO₂' as const,
    basis: 'wskaźnik dla energii elektrycznej u odbiorców końcowych — średnia krajowa (metoda location-based)',
    source: {
      publisher: 'KOBiZE',
      title: 'Wskaźniki emisyjności CO₂, SO₂, NOx, CO i pyłu całkowitego dla energii elektrycznej za 2024 rok (553 kg CO₂/MWh u odbiorców końcowych)',
      dataYear: 2024,
      published: '2025-12-23',
      url: 'https://www.kobize.pl/uploads/materialy/materialy_do_pobrania/aktualnosci/2025/142_Wskazniki_emisyjnosci_2025.pdf',
    } satisfies FactorSource,
  },

  // Paliwa: kg CO₂ na litr = gęstość [kg/l] × wartość opałowa [MJ/kg] × wskaźnik emisji [kg CO₂/GJ] ÷ 1000.
  fuels: {
    petrol: {
      label: 'Benzyna silnikowa',
      ncv: 44.3, // MJ/kg
      ef: 69.3, // kg CO₂/GJ
      density: 0.7475, // kg/l — środek zakresu 720–775 kg/m³
      densityNote: 'środek zakresu 720–775 kg/m³',
      source: KOBIZE_FUELS,
      densitySource: FUEL_QUALITY_REG,
    },
    diesel: {
      label: 'Olej napędowy',
      ncv: 43.0,
      ef: 74.1,
      density: 0.8325, // kg/l — środek zakresu 820–845 kg/m³ (olej standardowy)
      densityNote: 'środek zakresu 820–845 kg/m³',
      source: KOBIZE_FUELS,
      densitySource: FUEL_QUALITY_REG,
    },
    lpg: {
      label: 'Gaz ciekły LPG',
      ncv: 47.3,
      ef: 63.1,
      density: 0.549, // kg/l — skład propan/butan zmienia się sezonowo
      densityNote: 'ok. 549 kg/m³ (skład zmienia się sezonowo)',
      source: KOBIZE_FUELS,
      densitySource: LPG_SDS,
    },
  } satisfies Record<FuelKey, { label: string; ncv: number; ef: number; density: number; densityNote: string; source: FactorSource; densitySource: FactorSource }>,

  // Gaz ziemny wysokometanowy spalany w firmie (kocioł, kuchnia, procesy) — opcjonalne źródło Scope 1.
  gas: {
    label: 'Gaz ziemny wysokometanowy',
    ncvPerM3: 37.17, // MJ/m³
    ef: 56.18, // kg CO₂/GJ
    source: KOBIZE_FUELS,
  },

  fuelGases: 'CO₂' as const,

  // Tryb szacunkowy floty: przyjęte średnie spalanie (l/100 km). To założenie, nie dane producenta ani źródła urzędowego —
  // interfejs pokazuje je i pozwala zmienić.
  vehicleTypes: {
    car: { label: 'Samochód osobowy', consumption: { petrol: 7.5, diesel: 6.0, lpg: 9.5 } },
    van: { label: 'Samochód dostawczy do 3,5 t', consumption: { petrol: 11.0, diesel: 9.5, lpg: 13.0 } },
  },

  limits: {
    consumptionMin: 2,
    consumptionMax: 40,
    kmPerVehicleMax: 200_000,
    vehiclesMax: 1000,
    electricityWarnKwh: 50_000_000,
    litresWarn: 2_000_000,
    gasWarnM3: 10_000_000,
  },

  frameworks: [
    { label: 'GHG Protocol — Corporate Standard (Scope 1 i Scope 2)', url: 'https://ghgprotocol.org/corporate-standard' },
    { label: 'GHG Protocol — Scope 2 Guidance (metody location-based i market-based)', url: 'https://ghgprotocol.org/scope-2-guidance' },
    { label: 'Komisja Europejska — Zalecenie (UE) 2025/1710 w sprawie dobrowolnego standardu sprawozdawczości dla MŚP (VSME), moduł B3', url: 'https://eur-lex.europa.eu/eli/reco/2025/1710/oj/eng' },
    { label: 'EFRAG — VSME Standard (Annex I)', url: 'https://knowledgehub.efrag.org/eng/interactive/vsme/vsme-standard-annex-i/2025-07-30-ec-rec' },
  ],
} as const;

export type EmissionFactors = typeof EMISSION_FACTORS;

/** Pozycje zawsze poza zakresem obliczenia — pokazywane na stronie i w PDF. */
export const ALWAYS_OUT_OF_SCOPE = [
  'Ciepło sieciowe (miejskie) — nie ma jednego krajowego wskaźnika; potrzebny jest wskaźnik Twojego dostawcy ciepła.',
  'Inne paliwa i źródła spalania: olej opałowy, węgiel, pellet, CNG/LNG, agregaty, maszyny i urządzenia.',
  'Emisje z czynników chłodniczych (klimatyzacja, pompy ciepła, chłodnie) i emisje procesowe.',
  'Metan (CH₄) i podtlenek azotu (N₂O) — wynik obejmuje wyłącznie CO₂, więc nie jest to wartość w CO₂e.',
  'Scope 2 metodą market-based (umowy na „zieloną” energię, gwarancje pochodzenia).',
  'Energia z własnej instalacji (np. fotowoltaika) zużyta na miejscu — nie jest energią kupioną.',
  'Scope 3: zakupione towary i usługi, transport zewnętrzny, podróże służbowe, dojazdy pracowników, odpady i inne.',
] as const;
