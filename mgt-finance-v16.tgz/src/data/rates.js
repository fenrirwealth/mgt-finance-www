// Parametry podatkowo-składkowe – rok 2026.
// Aktualizacja raz w roku (styczeń). Stopy NBP i kursy walut pobierane są na żywo z api NBP.
export const RATES = {
  year: 2026,
  minWage: 4806,
  avgWageForecast: 9420,
  zus: {
    full: { base: 5652.0, emerytalna: 1103.27, rentowa: 452.16, chorobowa: 138.47, wypadkowa: 94.39, fp: 138.47 },
    pref: { base: 1441.8, emerytalna: 281.44, rentowa: 115.34, chorobowa: 35.32, wypadkowa: 24.08, fp: 0 },
    start: { base: 0, emerytalna: 0, rentowa: 0, chorobowa: 0, wypadkowa: 0, fp: 0 },
  },
  health: {
    min: 432.54, // 9% minimalnego wynagrodzenia – skala i liniowy
    scaleRate: 0.09,
    linearRate: 0.049,
    linearDeductLimit: 14100, // roczny limit odliczenia
    lumpsum: [
      { upTo: 60000, amount: 498.35 },
      { upTo: 300000, amount: 830.58 },
      { upTo: Infinity, amount: 1495.04 },
    ],
  },
  pit: {
    threshold: 120000,
    low: 0.12,
    high: 0.32,
    freeReduction: 3600, // rocznie (300 zł/mies.)
    linear: 0.19,
    solidarityThreshold: 1000000,
  },
  employee: { emerytalna: 0.0976, rentowa: 0.015, chorobowa: 0.0245, kup: 250, kupOut: 300 },
  employer: { emerytalna: 0.0976, rentowa: 0.065, wypadkowa: 0.0167, fp: 0.0245, fgsp: 0.001 },
  lumpsumRates: [
    { v: 0.17, l: '17% – wolne zawody' },
    { v: 0.15, l: '15% – m.in. doradztwo, reklama' },
    { v: 0.14, l: '14% – usługi IT, medyczne' },
    { v: 0.12, l: '12% – programowanie' },
    { v: 0.085, l: '8,5% – pozostałe usługi, najem' },
    { v: 0.055, l: '5,5% – produkcja, budowlanka' },
    { v: 0.03, l: '3% – handel, gastronomia' },
  ],
  // wartości zapasowe – nadpisywane danymi z NBP
  nbpFallback: { ref: 3.75, lombard: 4.25, date: '2026-03-05' },
};

export const GOV = [
  { group: 'Podatki', items: [
    { n: 'e-Urząd Skarbowy', d: 'Rozliczenia, zaświadczenia, pisma do US', u: 'https://www.podatki.gov.pl/e-urzad-skarbowy/' },
    { n: 'Twój e-PIT', d: 'Roczne zeznania PIT online', u: 'https://www.podatki.gov.pl/pit/twoj-e-pit/' },
    { n: 'KSeF – e-Faktury', d: 'Krajowy System e-Faktur', u: 'https://ksef.podatki.gov.pl/' },
    { n: 'e-Deklaracje', d: 'Wysyłka deklaracji podatkowych', u: 'https://www.podatki.gov.pl/e-deklaracje/' },
    { n: 'Mikrorachunek podatkowy', d: 'Generator indywidualnego rachunku', u: 'https://www.podatki.gov.pl/generator-mikrorachunku-podatkowego' },
    { n: 'Biała lista VAT', d: 'Wykaz podatników VAT i rachunków', u: 'https://www.podatki.gov.pl/wykaz-podatnikow-vat-wyszukiwarka' },
    { n: 'VIES', d: 'Weryfikacja unijnych numerów VAT', u: 'https://ec.europa.eu/taxation_customs/vies/' },
    { n: 'e-Sprawozdania', d: 'Sprawozdania finansowe do KAS', u: 'https://e-sprawozdania.mf.gov.pl/' },
  ]},
  { group: 'ZUS i kadry', items: [
    { n: 'eZUS (dawniej PUE)', d: 'Logowanie do elektronicznych usług ZUS', u: 'https://www.zus.pl/ezus/logowanie' },
    { n: 'Płatnik / e-Płatnik', d: 'Rozliczenia składek', u: 'https://www.zus.pl/firmy/program-platnik' },
    { n: 'e-Zwolnienia (e-ZLA)', d: 'Zwolnienia lekarskie pracowników', u: 'https://www.zus.pl/ezus/zwolnienia-lekarskie' },
    { n: 'PIP', d: 'Państwowa Inspekcja Pracy', u: 'https://www.pip.gov.pl/' },
  ]},
  { group: 'Rejestry i firma', items: [
    { n: 'CEIDG', d: 'Rejestracja i zmiany JDG', u: 'https://www.biznes.gov.pl/pl/firma' },
    { n: 'Portal S24 / eKRS', d: 'Rejestracja i wnioski spółek', u: 'https://ekrs.ms.gov.pl/' },
    { n: 'Wyszukiwarka KRS', d: 'Odpisy i dane spółek', u: 'https://wyszukiwarka-krs.ms.gov.pl/' },
    { n: 'REGON (GUS)', d: 'Wyszukiwarka podmiotów', u: 'https://wyszukiwarkaregon.stat.gov.pl/' },
    { n: 'CRBR', d: 'Rejestr beneficjentów rzeczywistych', u: 'https://crbr.podatki.gov.pl/' },
    { n: 'biznes.gov.pl', d: 'Serwis informacyjny dla przedsiębiorcy', u: 'https://www.biznes.gov.pl/' },
    { n: 'Kursy walut NBP', d: 'Tabele kursów średnich', u: 'https://nbp.pl/statystyka-i-sprawozdawczosc/kursy/' },
    { n: 'Monitor Sądowy (MSiG)', d: 'Ogłoszenia sądowe i gospodarcze', u: 'https://wyszukiwarka-msig.ms.gov.pl/' },
  ]},
];

export const FEEDS = [
  { name: 'ZUS – aktualności', short: 'ZUS', url: 'https://www.zus.pl/o-zus/aktualnosci/-/asset_publisher/aktualnosci/rss' },
  { name: 'ZUS – wyjaśnienia', short: 'ZUS', url: 'https://www.zus.pl/baza-wiedzy/biezace-wyjasnienia-komorek-merytorycznych/-/asset_publisher/biezace-wyjasnienia-komorek-merytorycznych/rss' },
  { name: 'ZUS – komunikaty techniczne', short: 'ZUS tech', url: 'https://www.zus.pl/o-zus/komunikaty/komunikaty-techniczne/-/asset_publisher/komunikaty-techniczne/rss' },
  { name: 'Prawo.pl – podatki', short: 'Podatki', url: 'https://www.prawo.pl/rss/podatki.xml' },
  { name: 'Prawo.pl – rachunkowość', short: 'Rachunkowość', url: 'https://www.prawo.pl/rss/rachunkowosc.xml' },
  { name: 'Prawo.pl – biznes', short: 'Biznes', url: 'https://www.prawo.pl/rss/biznes.xml' },
];
