// Parametry symulatora „Twoja firma w trzech scenariuszach” — rok podatkowy 2026.
// Aktualizacja: raz w roku (styczeń) oraz po każdej zmianie przepisów. Zmieniaj tylko wartości,
// logika obliczeń jest w src/lib/business-forms.ts. Kwoty miesięczne w zł, stawki jako ułamki.

export const FORMS_2026 = {
  year: 2026,
  verifiedOn: '2026-10-03',

  minWage: 4806,

  // Składki społeczne przedsiębiorcy (JDG) i wspólnika jednoosobowej sp. z o.o. — kwoty miesięczne
  zus: {
    full: { base: 5652.0, emerytalna: 1103.27, rentowa: 452.16, chorobowa: 138.47, wypadkowa: 94.39, fp: 138.47 },
    pref: { base: 1441.8, emerytalna: 281.44, rentowa: 115.34, chorobowa: 35.32, wypadkowa: 24.08, fp: 0 },
    start: { base: 0, emerytalna: 0, rentowa: 0, chorobowa: 0, wypadkowa: 0, fp: 0 },
  },

  health: {
    linearRate: 0.049, // JDG na podatku liniowym — % dochodu
    linearMinMonthly: 432.54, // 9% × minimalne wynagrodzenie 4 806 zł
    linearDeductionLimit: 14_100, // roczny limit odliczenia składki zdrowotnej na liniowym
    soleShareholderMonthly: 432.54, // wspólnik jednoosobowej sp. z o.o.: 9% × minimalne wynagrodzenie
  },

  pit: {
    linear: 0.19,
    dividend: 0.19,
    solidarityRate: 0.04, // danina solidarnościowa
    solidarityThreshold: 1_000_000,
  },

  cit: {
    standard: 0.19,
    reduced: 0.09,
    // 9%: przychody w roku podatkowym ≤ 2 mln EUR (kurs NBP z 2.01.2026: 4,2156 zł) i status małego podatnika
    // lub rozpoczęcie działalności; wyłączenie na rok utworzenia i następny dla podmiotów z przekształcenia JDG
    reducedRevenueLimit: 8_431_000,
    smallTaxpayerGrossLimit: 8_517_000, // 2 mln EUR × 4,2586 zł (kurs z 1.10.2025), sprzedaż z VAT za rok poprzedni
    minimumTaxProfitabilityThreshold: 0.02, // podatek minimalny — model go nie liczy, tylko ostrzega
  },

  estonian: {
    smallRate: 0.1, // mały podatnik lub rozpoczynający działalność
    standardRate: 0.2,
    smallDividendCredit: 0.9, // odliczenie od PIT od dywidendy: 90% ryczałtu przypadającego na wypłatę
    standardDividendCredit: 0.7,
  },

  vatForSmallTaxpayerProxy: 0.23, // przychód netto × 1,23 jako przybliżenie sprzedaży brutto z roku poprzedniego

  // Domyślne koszty obsługi — cennik MGT Finance (netto, miesięcznie)
  serviceCosts: { jdg: 249, company: 500, companyOther: 100 },

  sources: [
    { label: 'ZUS — składki przedsiębiorców w 2026 r. (analiza, luty 2026)', url: 'https://www.zus.pl/documents/10182/13364587/Sk%C5%82adki+przedsi%C4%99biorc%C3%B3w+w+2026+roku_DFF.pdf/c8d4e1dc-c80b-91d6-7453-02309976f713' },
    { label: 'ZUS — składka zdrowotna w 2026 r.', url: 'https://www.zus.pl/en/-/informacja-w-sprawie-podstawy-wymiaru-sk%C5%82adki-oraz-kwoty-sk%C5%82adki-na-ubezpieczenie-zdrowotne-w-2026-r.' },
    { label: 'Ministerstwo Finansów — stawki i limity w estońskim CIT', url: 'https://www.podatki.gov.pl/podatki-firmowe/cit/cit-estonski/stawki-i-limity-w-estonskim-cit' },
    { label: 'Ministerstwo Finansów — warunki estońskiego CIT', url: 'https://www.podatki.gov.pl/podatki-firmowe/cit/cit-estonski/informacje-podstawowe-cit-estonski' },
    { label: 'Ustawa o CIT — art. 19 (stawka 9%), art. 28c–28t (ryczałt od dochodów spółek)', url: 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU19920210086' },
    { label: 'Ustawa o PIT — art. 30a ust. 19 (odliczenie ryczałtu od PIT od dywidendy), art. 30c, art. 30h', url: 'https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU19910800350' },
  ],
} as const;

export type FormsParams = typeof FORMS_2026;
