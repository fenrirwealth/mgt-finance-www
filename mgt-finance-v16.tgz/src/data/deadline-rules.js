// Reguły kalendarza podatkowego MGT Finance — dane, nie logika. Silnik: src/lib/deadlines.js.
//
// Każda reguła opisuje obowiązek powtarzający się co roku. Pola:
//   id          stały identyfikator (część UID wydarzenia w .ics — nie zmieniaj po publikacji)
//   cat         kategoria (klucz CATS)
//   title       nazwa obowiązku
//   desc(ctx)   opis; ctx = { y, m0, prev, prevLoc } (rok, miesiąc 0–11, poprzedni miesiąc: „wrzesień” / „wrześniu”)
//   when(y)     lista dat nominalnych [ [m0, d] … ] — przed przesunięciem na dzień roboczy
//   appliesTo   alternatywy profilu: [['spolka'], ['jdg','vat']] = „spółka” LUB „JDG i VAT”
//   source      { name, basis, url } — źródło prawne; url do tekstu aktu lub strony urzędu
//   verifiedAt  data sprawdzenia reguły ze źródłem przez MGT Finance (null = do potwierdzenia)
//   updatedAt   data ostatniej zmiany reguły (null = bez zmian od publikacji)
//
// Zasada: nie dopisujemy źródeł ani dat weryfikacji, których nikt nie sprawdził.

export const PROFILE = [
  { key: 'jdg', code: 'j', label: 'Jednoosobowa działalność gospodarcza' },
  { key: 'spolka', code: 's', label: 'Spółka z o.o.' },
  { key: 'pracodawca', code: 'p', label: 'Zatrudniam pracowników lub zleceniobiorców' },
  { key: 'vat', code: 'v', label: 'Czynny podatnik VAT' },
  { key: 'vatue', code: 'u', label: 'Transakcje w UE (VAT UE)' },
];
export const DEFAULT_PROFILE = ['jdg', 'spolka', 'pracodawca', 'vat'];

export const ALARM_OPTIONS = [1, 2, 3, 5, 7]; // dni przed terminem
export const DEFAULT_ALARMS = [3, 1];
export const ALARM_HOUR = 9; // godzina przypomnienia w dniu alarmu (czas lokalny kalendarza)

export const CATS = {
  zus: { label: 'ZUS', color: '#2f6f8f' },
  pit: { label: 'PIT', color: '#8a6a5e' },
  cit: { label: 'CIT', color: '#1a1e40' },
  vat: { label: 'VAT / JPK', color: '#a8552f' },
  roczne: { label: 'Roczne', color: '#6d5a8f' },
  ksef: { label: 'KSeF', color: '#2f7a55' },
};

// Akty prawne (tekst w ISAP — Internetowy System Aktów Prawnych Sejmu RP)
const ISAP = (id) => `https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=${id}`;
const ACT = {
  sus: { name: 'Ustawa o systemie ubezpieczeń społecznych', url: ISAP('WDU19981370887') },
  pit: { name: 'Ustawa o podatku dochodowym od osób fizycznych', url: ISAP('WDU19910800350') },
  cit: { name: 'Ustawa o podatku dochodowym od osób prawnych', url: ISAP('WDU19920210086') },
  vat: { name: 'Ustawa o podatku od towarów i usług', url: ISAP('WDU20040540535') },
  uor: { name: 'Ustawa o rachunkowości', url: ISAP('WDU19941210591') },
  op: { name: 'Ordynacja podatkowa', url: ISAP('WDU19971370926') },
};
export const SHIFT_RULE = { name: 'Ordynacja podatkowa', basis: 'art. 12 § 5', url: ACT.op.url };

const monthly = (d) => () => Array.from({ length: 12 }, (_, m0) => [m0, d]);
const quarterly = (months, d) => () => months.map((m0) => [m0, d]);
const once = (m0, d) => () => [[m0, d]];
const lastOf = (m0) => (y) => [[m0, new Date(Date.UTC(y, m0 + 1, 0)).getUTCDate()]];
const onlyIn = (year, m0, d) => (y) => (y === year ? [[m0, d]] : []);

export const RULES = [
  {
    id: 'zus-15', cat: 'zus', title: 'Składki ZUS – spółki',
    desc: ({ prev }) => `Termin opłacenia składek i przekazania dokumentów rozliczeniowych za ${prev} przez płatników posiadających osobowość prawną – np. spółkę z o.o., która zgłasza do ubezpieczeń pracowników, zleceniobiorców lub członków zarządu.`,
    when: monthly(15), appliesTo: [['spolka']],
    source: { name: ACT.sus.name, basis: 'art. 47 ust. 1', url: ACT.sus.url }, verifiedAt: '2026-10-04', updatedAt: null,
  },
  {
    id: 'zus-20', cat: 'zus', title: 'Składki ZUS – działalność gospodarcza',
    desc: ({ prev }) => `Termin opłacenia własnych składek (społecznych, zdrowotnej, FP) za ${prev}, a jeśli zatrudniasz – także składek za pracowników i zleceniobiorców wraz z dokumentami rozliczeniowymi.`,
    when: monthly(20), appliesTo: [['jdg']],
    source: { name: ACT.sus.name, basis: 'art. 47 ust. 1', url: ACT.sus.url }, verifiedAt: '2026-10-04', updatedAt: null,
  },
  {
    id: 'pit-platnik', cat: 'pit', title: 'Zaliczki PIT od wynagrodzeń',
    desc: ({ prevLoc }) => `Wpłata zaliczek na PIT pobranych w ${prevLoc} od wynagrodzeń pracowników i umów cywilnoprawnych.`,
    when: monthly(20), appliesTo: [['pracodawca']],
    source: { name: ACT.pit.name, basis: 'art. 38 ust. 1, art. 41, art. 42 ust. 1', url: ACT.pit.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'pit-mies', cat: 'pit', title: 'Zaliczka PIT / ryczałt – miesięcznie',
    desc: ({ prev }) => `Zaliczka na podatek dochodowy (skala, podatek liniowy) lub ryczałt za ${prev} – dla rozliczających się miesięcznie.`,
    when: monthly(20), appliesTo: [['jdg']],
    source: { name: ACT.pit.name, basis: 'art. 44 ust. 6', url: ACT.pit.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'pit-kw', cat: 'pit', title: 'Zaliczka PIT / ryczałt – kwartalnie',
    desc: () => 'Zaliczka na podatek dochodowy lub ryczałt za poprzedni kwartał – dla rozliczających się kwartalnie. Za IV kwartał zaliczki się nie wpłaca – rozliczasz go w zeznaniu rocznym.',
    when: quarterly([3, 6, 9], 20), appliesTo: [['jdg']],
    source: { name: ACT.pit.name, basis: 'art. 44 ust. 3g i 6', url: ACT.pit.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'cit-zal', cat: 'cit', title: 'Zaliczka CIT',
    desc: ({ prev }) => `Zaliczka na podatek CIT za ${prev}. Mali podatnicy i firmy w pierwszym roku działalności mogą wpłacać zaliczki kwartalnie; spółki na estońskim CIT zaliczek nie wpłacają.`,
    when: monthly(20), appliesTo: [['spolka']],
    source: { name: ACT.cit.name, basis: 'art. 25 ust. 1a i 1b', url: ACT.cit.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'jpk-v7', cat: 'vat', title: 'JPK_V7 i zapłata VAT',
    desc: ({ prev }) => `Wysyłka JPK_V7M z deklaracją i zapłata VAT za ${prev}. Przy rozliczeniu kwartalnym (JPK_V7K) w tym terminie wysyłasz część ewidencyjną za miesiąc.`,
    when: monthly(25), appliesTo: [['vat']],
    source: { name: ACT.vat.name, basis: 'art. 99 ust. 1, art. 103 ust. 1, art. 109 ust. 3b', url: ACT.vat.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'jpk-v7k', cat: 'vat', title: 'VAT za kwartał – JPK_V7K',
    desc: () => 'Zapłata VAT za poprzedni kwartał i JPK_V7K z częścią deklaracyjną – dla rozliczających się kwartalnie.',
    when: quarterly([0, 3, 6, 9], 25), appliesTo: [['vat']],
    source: { name: ACT.vat.name, basis: 'art. 99 ust. 2, art. 103 ust. 2', url: ACT.vat.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'vat-ue', cat: 'vat', title: 'VAT-UE – informacja podsumowująca',
    desc: ({ prev }) => `Informacja podsumowująca o transakcjach wewnątrzwspólnotowych za ${prev} – składasz ją tylko wtedy, gdy w tym miesiącu były takie transakcje.`,
    when: monthly(25), appliesTo: [['vatue']],
    source: { name: ACT.vat.name, basis: 'art. 100 ust. 3', url: ACT.vat.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'pit-4r', cat: 'roczne', title: 'PIT-4R, PIT-8AR i PIT-11 do urzędu skarbowego',
    desc: ({ y }) => `Roczne deklaracje płatnika za ${y - 1} r. oraz informacje PIT-11 przesyłane do urzędu skarbowego.`,
    when: once(0, 31), appliesTo: [['pracodawca']],
    source: { name: ACT.pit.name, basis: 'art. 42 ust. 1a i 2', url: ACT.pit.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'zus-iwa', cat: 'zus', title: 'ZUS IWA',
    desc: ({ y }) => `Informacja o danych do ustalenia stopy składki wypadkowej za ${y - 1} r. – dla płatników zgłaszających do ubezpieczenia wypadkowego co najmniej 10 osób.`,
    when: once(0, 31), appliesTo: [['pracodawca']],
    source: { name: 'Zakład Ubezpieczeń Społecznych', basis: null, url: null }, verifiedAt: null, updatedAt: null, // TODO: uzupełnić podstawę prawną i link
  },
  {
    id: 'forma-opodatkowania', cat: 'pit', title: 'Zmiana formy opodatkowania',
    desc: ({ y }) => `Ostatni dzień na zmianę formy opodatkowania na ${y} r., jeśli pierwszy przychód w roku uzyskałeś w styczniu.`,
    when: once(1, 20), appliesTo: [['jdg']],
    source: { name: ACT.pit.name, basis: 'art. 9a ust. 2', url: ACT.pit.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'pit-11', cat: 'roczne', title: 'PIT-11 dla pracowników',
    desc: ({ y }) => `Przekazanie informacji PIT-11 za ${y - 1} r. pracownikom i zleceniobiorcom.`,
    when: lastOf(1), appliesTo: [['pracodawca']],
    source: { name: ACT.pit.name, basis: 'art. 39 ust. 1, art. 42 ust. 2', url: ACT.pit.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'cit-8', cat: 'roczne', title: 'CIT-8 i sprawozdanie finansowe',
    desc: ({ y }) => `Złożenie zeznania CIT-8 i zapłata podatku za ${y - 1} r. oraz sporządzenie sprawozdania finansowego (przy roku podatkowym równym kalendarzowemu).`,
    when: once(2, 31), appliesTo: [['spolka']],
    source: { name: `${ACT.cit.name}; ${ACT.uor.name}`, basis: 'art. 27 ust. 1 ustawy o CIT; art. 52 ust. 1 ustawy o rachunkowości', url: ACT.cit.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'pit-roczny', cat: 'roczne', title: 'PIT-36, PIT-36L, PIT-28 – zeznanie roczne',
    desc: ({ y }) => `Zeznanie roczne za ${y - 1} r. i ewentualna dopłata podatku.`,
    when: once(3, 30), appliesTo: [['jdg']],
    source: { name: ACT.pit.name, basis: 'art. 45 ust. 1', url: ACT.pit.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'zdrowotna-roczna', cat: 'zus', title: 'Roczne rozliczenie składki zdrowotnej',
    desc: ({ y }) => `Rozliczenie składki zdrowotnej za ${y - 1} r. w dokumentach rozliczeniowych za kwiecień – dla przedsiębiorców na skali, podatku liniowym i ryczałcie.`,
    when: once(4, 20), appliesTo: [['jdg']],
    source: { name: 'Zakład Ubezpieczeń Społecznych', basis: null, url: 'https://www.zus.pl/en/-/roczne-rozliczenie-sk%C5%82adki-zdrowotnej-za-2025-r.' }, verifiedAt: '2026-10-04', updatedAt: null,
  },
  {
    id: 'zatwierdzenie-sf', cat: 'roczne', title: 'Zatwierdzenie sprawozdania finansowego',
    desc: ({ y }) => `Zgromadzenie wspólników zatwierdza sprawozdanie finansowe za ${y - 1} r.`,
    when: once(5, 30), appliesTo: [['spolka']],
    source: { name: ACT.uor.name, basis: 'art. 53 ust. 1', url: ACT.uor.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'sf-krs', cat: 'roczne', title: 'Sprawozdanie finansowe do KRS',
    desc: () => 'Złożenie zatwierdzonego sprawozdania finansowego do Repozytorium Dokumentów Finansowych – 15 dni od zatwierdzenia (przy zatwierdzeniu 30 czerwca).',
    when: once(6, 15), appliesTo: [['spolka']],
    source: { name: ACT.uor.name, basis: 'art. 69 ust. 1', url: ACT.uor.url }, verifiedAt: null, updatedAt: null,
  },
  {
    id: 'ksef-duze', cat: 'ksef', title: 'KSeF obowiązkowy – największe firmy',
    desc: () => 'Obowiązek wystawiania faktur w KSeF dla podatników, których sprzedaż w 2024 r. przekroczyła 200 mln zł.',
    when: onlyIn(2026, 1, 1), appliesTo: [['vat'], ['jdg'], ['spolka']],
    source: { name: 'Ministerstwo Finansów – Krajowy System e-Faktur', basis: null, url: 'https://ksef.podatki.gov.pl/' }, verifiedAt: '2026-10-04', updatedAt: null,
  },
  {
    id: 'ksef-pozostali', cat: 'ksef', title: 'KSeF obowiązkowy – pozostali podatnicy',
    desc: () => 'Obowiązek wystawiania faktur w KSeF dla pozostałych podatników.',
    when: onlyIn(2026, 3, 1), appliesTo: [['vat'], ['jdg'], ['spolka']],
    source: { name: 'Ministerstwo Finansów – Krajowy System e-Faktur', basis: null, url: 'https://ksef.podatki.gov.pl/' }, verifiedAt: '2026-10-04', updatedAt: null,
  },
  {
    id: 'ksef-mali', cat: 'ksef', title: 'KSeF – najmniejsi podatnicy',
    desc: () => 'Koniec okresu przejściowego dla podatników, których miesięczna sprzedaż udokumentowana fakturami nie przekracza 10 000 zł.',
    when: onlyIn(2027, 0, 1), appliesTo: [['vat'], ['jdg'], ['spolka']],
    source: { name: 'Ministerstwo Finansów – Krajowy System e-Faktur', basis: null, url: 'https://ksef.podatki.gov.pl/' }, verifiedAt: '2026-10-04', updatedAt: null,
  },
];
