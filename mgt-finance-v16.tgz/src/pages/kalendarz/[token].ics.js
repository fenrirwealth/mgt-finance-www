// Subskrybowany kalendarz podatkowy dopasowany do profilu: /kalendarz/{profil}-{przypomnienia}.ics, np. /kalendarz/spv-31.ics
// Token ma skończoną liczbę kanonicznych wariantów (bez dowolnych parametrów), nie zawiera danych osobowych.
// Kalendarz zawiera bieżący i następny rok; klienci kalendarzy odświeżają go cyklicznie (REFRESH-INTERVAL 12 h).
import { parseToken, feedPath } from '../../lib/deadlines.js';
import { feedResponse } from '../../lib/calendar-feed.js';
export const prerender = false;

export function GET({ params, redirect }) {
  const t = parseToken(params.token);
  if (!t) return new Response('Nie znaleziono kalendarza.', { status: 404, headers: { 'content-type': 'text/plain; charset=utf-8', 'x-robots-tag': 'noindex' } });
  if (!t.isCanonical) return redirect(feedPath(t.canonical), 301);
  return feedResponse(t.profile, t.alarms);
}
