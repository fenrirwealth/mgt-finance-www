import nodemailer from 'nodemailer';
export const prerender = false;
const env = (k) => process.env[k] || import.meta.env[k];
export async function POST({ request }) {
  const h = { 'content-type': 'application/json' };
  let f;
  try { f = await request.json(); } catch { return new Response('{"ok":false}', { status: 400, headers: h }); }
  if (f.website) return new Response('{"ok":true}', { headers: h }); // honeypot
  const name = String(f.name || '').slice(0, 120).trim();
  const contact = String(f.contact || '').slice(0, 160).trim();
  const message = String(f.message || '').slice(0, 4000).trim();
  if (!name || !contact || !f.consent) return new Response(JSON.stringify({ ok: false, error: 'Uzupełnij wymagane pola.' }), { status: 400, headers: h });
  const host = env('SMTP_HOST');
  if (!host) { return new Response(JSON.stringify({ ok: false, error: 'nosmtp' }), { status: 503, headers: h }); }
  try {
    const t = nodemailer.createTransport({ host, port: +(env('SMTP_PORT') || 465), secure: (env('SMTP_PORT') || '465') === '465', auth: { user: env('SMTP_USER'), pass: env('SMTP_PASS') } });
    await t.sendMail({
      from: `"Strona MGT Finance" <${env('SMTP_FROM') || env('SMTP_USER')}>`,
      to: env('CONTACT_TO') || 'biuro@mgtfinance.pl',
      replyTo: contact.includes('@') ? contact : undefined,
      subject: `Zapytanie ze strony: ${f.topic || 'ogólne'} – ${name}`,
      text: `Imię i nazwisko / firma: ${name}\nKontakt: ${contact}\nTemat: ${f.topic || '-'}\n\n${message}`,
    });
    return new Response('{"ok":true}', { headers: h });
  } catch (e) {
    console.error('[contact]', e.message);
    return new Response(JSON.stringify({ ok: false, error: 'send' }), { status: 502, headers: h });
  }
}
