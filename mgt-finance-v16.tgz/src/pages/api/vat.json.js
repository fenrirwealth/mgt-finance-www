import { cached, fetchText } from '../../lib/cache.js';
export const prerender = false;
const valid = (n) => { if (!/^\d{10}$/.test(n)) return false; const w=[6,5,7,2,3,4,5,6,7]; const s=w.reduce((a,x,i)=>a+x*+n[i],0)%11; return s===+n[9]; };
export async function GET({ url }) {
  const nip = (url.searchParams.get('nip') || '').replace(/\D/g, '');
  const h = { 'content-type': 'application/json' };
  if (!valid(nip)) return new Response(JSON.stringify({ error: 'Nieprawidłowy numer NIP.' }), { status: 400, headers: h });
  const date = new Date().toISOString().slice(0, 10);
  try {
    const data = await cached('vat:' + nip, 6 * 3600e3, async () => JSON.parse(await fetchText(`https://wl-api.mf.gov.pl/api/search/nip/${nip}?date=${date}`)));
    const s = data?.result?.subject;
    if (!s) return new Response(JSON.stringify({ found: false }), { headers: h });
    return new Response(JSON.stringify({ found: true, name: s.name, status: s.statusVat, regon: s.regon, krs: s.krs, address: s.workingAddress || s.residenceAddress, accounts: s.accountNumbers || [], registered: s.registrationLegalDate, requestId: data.result.requestId, date }), { headers: h });
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Usługa Ministerstwa Finansów chwilowo niedostępna.', fallback: 'https://www.podatki.gov.pl/wykaz-podatnikow-vat-wyszukiwarka' }), { status: 502, headers: h });
  }
}
