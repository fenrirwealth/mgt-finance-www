import { getRates } from '../../lib/nbp.js';
export const prerender = false;
export async function GET() {
  const r = await getRates();
  return new Response(JSON.stringify(r), { headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=1800' } });
}
