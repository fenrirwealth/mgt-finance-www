import { getNews } from '../../lib/news.js';
export const prerender = false;
export async function GET() {
  try {
    const items = await getNews();
    return new Response(JSON.stringify({ items, updated: new Date().toISOString() }), { headers: { 'content-type': 'application/json', 'cache-control': 'public, max-age=600' } });
  } catch (e) {
    return new Response(JSON.stringify({ items: [], error: 'unavailable' }), { status: 503, headers: { 'content-type': 'application/json' } });
  }
}
