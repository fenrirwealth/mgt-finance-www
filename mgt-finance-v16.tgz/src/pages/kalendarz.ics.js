// Dawny adres subskrypcji (/kalendarz.ics?who=…&alarm=…) — zostaje, aby nie przerwać istniejących subskrypcji.
// Parametry są mapowane na ten sam generator co /kalendarz/{token}.ics; nieznane wartości są ignorowane.
import { DEFAULT_PROFILE, PROFILE, normalizeAlarms } from '../lib/deadlines.js';
import { feedResponse } from '../lib/calendar-feed.js';
export const prerender = false;
export function GET({ url }) {
  const keys = PROFILE.map((p) => p.key);
  const who = (url.searchParams.get('who') || '').split(',').filter((w) => keys.includes(w));
  const alarms = normalizeAlarms([url.searchParams.get('alarm') || '2']);
  return feedResponse(who.length ? who : DEFAULT_PROFILE, alarms.length ? alarms : [2]);
}
