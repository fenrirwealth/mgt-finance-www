// Middleware: przekierowania ze starej strony, polska typografia, nagłówki bezpieczeństwa, limit zapytań API.
import { defineMiddleware } from 'astro:middleware';

const REDIRECTS = {
  '/wakacje-w-zus': '/blog/wakacje-w-zus',
  '/formularz-kontaktowy': '/kontakt',
  '/konsultacja-on-line': '/kontakt',
  '/home': '/',
  '/feed': '/aktualnosci',
};

// Twarde spacje po jednoliterowych wyrazach i krótkich spójnikach (tzw. sierotki) – tylko w tekście, poza skryptami.
const ORPHANS = /(^|[\s(„>\u00a0])([aiouwzAIOUWZ]|we|ze|na|do|od|po|to|by|że|iż|ul\.|al\.|nr|tel\.|ok\.)[ \t\r\n]+(?=[^\s<])/g;
function typography(html) {
  return html.replace(/(<(script|style|textarea|pre|code)[\s\S]*?<\/\2>)|(>)([^<]+)(?=<)/gi, (m, skip, _t, gt, text) => {
    if (skip) return skip;
    const fix = (x) => x.replace(ORPHANS, (_, pre, word) => pre + word + '\u00a0');
    let t = fix(fix(text));
    t = t.replace(/(\d)\s(zł|%|dni|dokumentów|mln|tys\.)/g, '$1 $2');
    return gt + t;
  });
}

const hits = new Map();
function limited(ip, key, max, windowMs) {
  const k = key + ':' + ip;
  const now = Date.now();
  const arr = (hits.get(k) || []).filter((t) => now - t < windowMs);
  arr.push(now);
  hits.set(k, arr);
  if (hits.size > 5000) hits.clear();
  return arr.length > max;
}

const SECURITY = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'SAMEORIGIN',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; font-src 'self'; connect-src 'self'; frame-src https://www.openstreetmap.org; form-action 'self' mailto:; base-uri 'self'; frame-ancestors 'self'",
};

export const onRequest = defineMiddleware(async (ctx, next) => {
  const path = ctx.url.pathname.replace(/\/+$/, '') || '/';
  if (REDIRECTS[path]) return ctx.redirect(REDIRECTS[path], 301);

  if (path.startsWith('/api/')) {
    let ip = 'local';
    try { ip = ctx.request.headers.get('x-forwarded-for')?.split(',')[0].trim() || ctx.clientAddress || 'local'; } catch {}
    const rule = path === '/api/contact' ? [5, 10 * 60e3] : path === '/api/vat.json' ? [30, 60e3] : [120, 60e3];
    if (limited(ip, path, rule[0], rule[1])) {
      return new Response(JSON.stringify({ error: 'Zbyt wiele zapytań. Spróbuj ponownie za chwilę.' }), { status: 429, headers: { 'content-type': 'application/json', 'retry-after': '60' } });
    }
  }

  const res = await next();
  const type = res.headers.get('content-type') || '';
  let out = res;
  if (type.includes('text/html')) {
    const html = typography(await res.text());
    out = new Response(html, { status: res.status, headers: res.headers });
  }
  try { for (const [k, v] of Object.entries(SECURITY)) out.headers.set(k, v); } catch {}
  return out;
});
