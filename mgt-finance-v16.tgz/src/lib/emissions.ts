// Silnik „Wstępnego zestawienia energii i wybranych emisji”. Czyste funkcje, bez DOM — testy: tests/emissions.test.ts.
// Wyniki w kg CO₂ (tylko CO₂ — takie są współczynniki źródłowe), energia w kWh.
import { ALWAYS_OUT_OF_SCOPE, EMISSION_FACTORS, type EmissionFactors, type FuelKey } from '../data/emission-factors.ts';

export type { FuelKey };
export type VehicleType = 'car' | 'van';
export type FleetMode = 'litres' | 'estimate';
export const FUEL_KEYS: FuelKey[] = ['petrol', 'diesel', 'lpg'];

/** Pole liczbowe: null = nie podano, NaN = niepoprawny zapis. */
export type Amount = number | null;

export type VehicleGroup = {
  type: VehicleType;
  fuel: FuelKey;
  count: Amount;
  kmPerVehicle: Amount;
  consumption: Amount; // l/100 km; null = przyjęte spalanie z danych
};

export type EmissionInputs = {
  company: string;
  period: string;
  electricityKwh: Amount;
  greenClaim: boolean;
  fleetMode: FleetMode;
  litres: Record<FuelKey, Amount>;
  otherFuels: boolean;
  groups: VehicleGroup[];
  gasM3: Amount;
};

export type Issue = { field: string; level: 'error' | 'warning'; message: string };

export type Line = {
  key: string;
  scope: 1 | 2;
  label: string;
  amount: number;
  amountUnit: string;
  estimated: boolean;
  energyKwh: number;
  co2Kg: number;
  formula: string;
  source: string;
};

export type EmissionResult = {
  inputs: EmissionInputs;
  lines: Line[];
  scope1Kg: number;
  scope2Kg: number;
  totalKg: number;
  energy: { electricityKwh: number; fuelsKwh: number; totalKwh: number };
  hasData: boolean;
  issues: Issue[];
  errors: number;
  outOfScope: string[];
  estimatedNotes: string[];
};

const nf = (v: number, d = 0) =>
  v.toLocaleString('pl-PL', { minimumFractionDigits: d, maximumFractionDigits: d, useGrouping: true }).replace(/[  ]/g, ' ');
export const fmt = nf;
/** Tony z dwoma miejscami po przecinku; poniżej 0,1 t — z trzema, żeby małe wartości nie znikały. */
export const tonnes = (kg: number) => nf(kg / 1000, kg > 0 && kg < 100 ? 3 : 2);

/** Zamienia wpis użytkownika na liczbę: „12 000,5” → 12000.5; puste → null; błędny zapis → NaN. */
export function parseAmount(raw: string | number | null | undefined): Amount {
  if (raw === null || raw === undefined) return null;
  if (typeof raw === 'number') return Number.isFinite(raw) ? raw : Number.NaN;
  const s = raw.replace(/[\s  ]/g, '').replace(',', '.');
  if (s === '') return null;
  if (!/^-?\d*\.?\d+$/.test(s)) return Number.NaN;
  return Number(s);
}

export function perLitre(k: FuelKey, p: EmissionFactors = EMISSION_FACTORS) {
  const f = p.fuels[k];
  return { co2: (f.density * f.ncv * f.ef) / 1000, kwh: (f.density * f.ncv) / 3.6 };
}
export function gasPerM3(p: EmissionFactors = EMISSION_FACTORS) {
  return { co2: (p.gas.ncvPerM3 * p.gas.ef) / 1000, kwh: p.gas.ncvPerM3 / 3.6 };
}
export function defaultConsumption(type: VehicleType, fuel: FuelKey, p: EmissionFactors = EMISSION_FACTORS) {
  return p.vehicleTypes[type].consumption[fuel];
}

export const EMPTY_INPUTS: EmissionInputs = {
  company: '',
  period: '2025',
  electricityKwh: null,
  greenClaim: false,
  fleetMode: 'litres',
  litres: { petrol: null, diesel: null, lpg: null },
  otherFuels: false,
  groups: [],
  gasM3: null,
};

export function calculate(raw: EmissionInputs, p: EmissionFactors = EMISSION_FACTORS): EmissionResult {
  const i: EmissionInputs = {
    ...raw,
    company: (raw.company ?? '').replace(/\s+/g, ' ').trim().slice(0, 160),
    period: (raw.period ?? '').replace(/\s+/g, ' ').trim().slice(0, 60),
  };
  const issues: Issue[] = [];
  const lines: Line[] = [];
  const outOfScope: string[] = [];
  const estimatedNotes: string[] = [];
  const L = p.limits;

  /** Sprawdza pole; zwraca wartość do obliczeń albo null (puste lub błędne). */
  const check = (field: string, v: Amount, warnAbove?: number, warnMsg?: string): number | null => {
    if (v === null) return null;
    if (Number.isNaN(v)) { issues.push({ field, level: 'error', message: 'Wpisz liczbę, np. 12 500 lub 12 500,5.' }); return null; }
    if (v < 0) { issues.push({ field, level: 'error', message: 'Wartość nie może być ujemna.' }); return null; }
    if (warnAbove !== undefined && v > warnAbove) issues.push({ field, level: 'warning', message: warnMsg ?? 'Bardzo duża wartość — sprawdź jednostkę.' });
    return v;
  };

  // Scope 2 — energia elektryczna (location-based)
  const el = check('electricityKwh', i.electricityKwh, L.electricityWarnKwh, 'Bardzo duża wartość — sprawdź, czy to kWh (a nie Wh).');
  if (el !== null) {
    const e = p.electricity;
    lines.push({
      key: 'electricity', scope: 2, label: e.label, amount: el, amountUnit: 'kWh', estimated: false,
      energyKwh: el, co2Kg: el * e.value,
      formula: `${nf(el)} kWh × ${nf(e.value, 3)} kg CO₂/kWh`,
      source: `KOBiZE, dane za ${e.source.dataYear} r.`,
    });
  }
  if (i.greenClaim) {
    outOfScope.push('Umowa na „zieloną” energię: w metodzie location-based liczymy średni wskaźnik krajowy niezależnie od umowy. Wynik market-based wymaga gwarancji pochodzenia lub danych sprzedawcy i nie jest tu liczony.');
  }

  // Scope 1 — flota
  if (i.fleetMode === 'litres') {
    for (const k of FUEL_KEYS) {
      const v = check(`litres.${k}`, i.litres[k], L.litresWarn, 'Bardzo duża wartość — sprawdź, czy to litry za wybrany okres.');
      if (v === null) continue;
      const f = perLitre(k, p);
      lines.push({
        key: `fuel-${k}`, scope: 1, label: `Flota — ${p.fuels[k].label.toLowerCase()}`, amount: v, amountUnit: 'l', estimated: false,
        energyKwh: v * f.kwh, co2Kg: v * f.co2,
        formula: `${nf(v)} l × ${nf(f.co2, 3)} kg CO₂/l`,
        source: `KOBiZE (WO/WE, dane za ${p.fuels[k].source.dataYear} r.), gęstość: ${p.fuels[k].densityNote}`,
      });
    }
  } else {
    i.groups.forEach((g, n) => {
      const id = `groups.${n}`;
      const name = `${p.vehicleTypes[g.type].label}, ${p.fuels[g.fuel].label.toLowerCase()}`;
      const count = check(`${id}.count`, g.count);
      const km = check(`${id}.kmPerVehicle`, g.kmPerVehicle);
      const cons = check(`${id}.consumption`, g.consumption);
      if (count !== null && (!Number.isInteger(count) || count > L.vehiclesMax)) {
        issues.push({ field: `${id}.count`, level: 'error', message: `Podaj liczbę pojazdów jako liczbę całkowitą (maks. ${L.vehiclesMax}).` });
        return;
      }
      if (km !== null && km > L.kmPerVehicleMax) {
        issues.push({ field: `${id}.kmPerVehicle`, level: 'error', message: `Przebieg ponad ${nf(L.kmPerVehicleMax)} km rocznie na pojazd jest mało prawdopodobny — sprawdź, czy to przebieg jednego pojazdu.` });
        return;
      }
      if (cons !== null && (cons < L.consumptionMin || cons > L.consumptionMax)) {
        issues.push({ field: `${id}.consumption`, level: 'error', message: `Spalanie powinno mieścić się w zakresie ${L.consumptionMin}–${L.consumptionMax} l/100 km.` });
        return;
      }
      if (!count) return; // pusta grupa lub zero pojazdów — nic do policzenia
      if (km === null || km === 0) {
        issues.push({ field: `${id}.kmPerVehicle`, level: 'error', message: 'Podaj średni roczny przebieg jednego pojazdu — sama liczba pojazdów nie wystarcza do obliczenia.' });
        outOfScope.push(`${name} (${nf(count)} szt.) — brak przebiegu, grupa nie została policzona.`);
        return;
      }
      const c = cons ?? defaultConsumption(g.type, g.fuel, p);
      const litres = (count * km * c) / 100;
      const f = perLitre(g.fuel, p);
      lines.push({
        key: `group-${n}`, scope: 1, label: `Flota (szacunek) — ${name}`, amount: litres, amountUnit: 'l', estimated: true,
        energyKwh: litres * f.kwh, co2Kg: litres * f.co2,
        formula: `${nf(count)} × ${nf(km)} km × ${nf(c, 1)} l/100 km = ${nf(litres)} l × ${nf(f.co2, 3)} kg CO₂/l`,
        source: `${cons === null ? 'przyjęte spalanie (założenie)' : 'spalanie podane przez użytkownika'}; KOBiZE (WO/WE)`,
      });
      estimatedNotes.push(`${name}: ${nf(count)} szt. × ${nf(km)} km × ${nf(c, 1)} l/100 km (${cons === null ? 'przyjęte spalanie — założenie' : 'spalanie podane przez użytkownika'}).`);
    });
  }
  if (i.otherFuels) outOfScope.push('Inne paliwa zużywane przez flotę (np. CNG, LNG, biopaliwa, wodór) — kalkulator nie ma dla nich współczynników; nie zostały policzone.');

  // Scope 1 — gaz ziemny (opcjonalnie)
  const gas = check('gasM3', i.gasM3, L.gasWarnM3, 'Bardzo duża wartość — sprawdź, czy to m³ za wybrany okres.');
  if (gas !== null) {
    const g = gasPerM3(p);
    lines.push({
      key: 'gas', scope: 1, label: p.gas.label, amount: gas, amountUnit: 'm³', estimated: false,
      energyKwh: gas * g.kwh, co2Kg: gas * g.co2,
      formula: `${nf(gas)} m³ × ${nf(g.co2, 3)} kg CO₂/m³`,
      source: `KOBiZE (WO/WE, dane za ${p.gas.source.dataYear} r.)`,
    });
  }

  const scope1Kg = lines.filter((l) => l.scope === 1).reduce((s, l) => s + l.co2Kg, 0);
  const scope2Kg = lines.filter((l) => l.scope === 2).reduce((s, l) => s + l.co2Kg, 0);
  const electricityKwh = lines.filter((l) => l.key === 'electricity').reduce((s, l) => s + l.energyKwh, 0);
  const fuelsKwh = lines.filter((l) => l.key !== 'electricity').reduce((s, l) => s + l.energyKwh, 0);

  return {
    inputs: i,
    lines,
    scope1Kg,
    scope2Kg,
    totalKg: scope1Kg + scope2Kg,
    energy: { electricityKwh, fuelsKwh, totalKwh: electricityKwh + fuelsKwh },
    hasData: lines.length > 0,
    issues,
    errors: issues.filter((x) => x.level === 'error').length,
    outOfScope: [...outOfScope, ...ALWAYS_OUT_OF_SCOPE],
    estimatedNotes,
  };
}

/** Krótkie podsumowanie do formularza kontaktowego — bez HTML. */
export function summaryText(r: EmissionResult): string {
  const out = [`Wstępne zestawienie energii i wybranych emisji (tylko CO₂, dane podane przez użytkownika)${r.inputs.period ? ` — okres: ${r.inputs.period}` : ''}:`];
  if (r.inputs.company) out.push(`Firma: ${r.inputs.company}`);
  for (const l of r.lines) out.push(`• Scope ${l.scope} · ${l.label}: ${l.formula.split(' = ').pop()} → ${tonnes(l.co2Kg)} t CO₂${l.estimated ? ' (szacunek)' : ''}`);
  out.push(`Scope 1: ${tonnes(r.scope1Kg)} t CO₂ · Scope 2 (location-based): ${tonnes(r.scope2Kg)} t CO₂ · razem: ${tonnes(r.totalKg)} t CO₂`);
  out.push(`Energia: ${nf(r.energy.totalKwh / 1000, 2)} MWh (w tym energia elektryczna ${nf(r.energy.electricityKwh / 1000, 2)} MWh)`);
  out.push('Chcę porozmawiać o uporządkowaniu danych o emisjach mojej firmy.');
  return out.join('\n');
}
