// Silnik symulatora „Twoja firma w trzech scenariuszach”.
// Czyste funkcje bez DOM — testowane w tests/business-forms.test.ts.
// Wszystkie kwoty wynikowe są ROCZNE, w złotych.

import { FORMS_2026, type FormsParams } from '../data/business-forms-2026.ts';

export type JdgZus = 'full' | 'pref' | 'start';
export type EstonianStatus = 'yes' | 'unknown' | 'no';
export type ScenarioKey = 'jdg' | 'cit' | 'estonian';

export interface Inputs {
  /** przychód netto (bez VAT), miesięcznie */
  revenue: number;
  /** koszty działalności netto, miesięcznie (bez kosztów obsługi formy) */
  costs: number;
  /** część zysku wypłacana właścicielowi w spółce, 0–1 */
  payout: number;
  jdgZus: JdgZus;
  sickness: boolean;
  /** liczba wspólników spółki */
  partners: 1 | 2;
  /** spółka powstaje z przekształcenia JDG (lub z aportu przedsiębiorstwa > 10 tys. EUR) */
  fromTransformation: boolean;
  estonianStatus: EstonianStatus;
  /** koszty obsługi (księgowość itp.), miesięcznie */
  serviceJdg: number;
  serviceCompany: number;
  serviceCompanyOther: number;
}

export interface Line {
  key: string;
  label: string;
  value: number;
}

export interface Scenario {
  key: ScenarioKey;
  name: string;
  revenue: number;
  businessCosts: number;
  serviceCosts: number;
  /** wynik przed podatkiem dochodowym (dla JDG: przed składkami i PIT) */
  profit: number;
  taxes: number;
  social: number;
  health: number;
  /** kwota faktycznie trafiająca do właściciela po wszystkich podatkach i jego składkach */
  toOwner: number;
  /** zysk pozostający w spółce (dla estońskiego CIT: jeszcze nieopodatkowany) */
  retained: number;
  taxLines: Line[];
  /** wynik orientacyjny — model nie obejmuje istotnej okoliczności */
  approximate: boolean;
  /** scenariusz niedostępny przy podanych odpowiedziach */
  unavailable: boolean;
  notes: string[];
}

export interface Result {
  inputs: Inputs;
  scenarios: [Scenario, Scenario, Scenario];
  smallTaxpayer: boolean;
  reducedCit: boolean;
  estonianRate: number;
  globalNotes: string[];
}

export const DEFAULT_INPUTS: Inputs = {
  revenue: 40_000,
  costs: 10_000,
  payout: 1,
  jdgZus: 'full',
  sickness: true,
  partners: 1,
  fromTransformation: false,
  estonianStatus: 'unknown',
  serviceJdg: FORMS_2026.serviceCosts.jdg,
  serviceCompany: FORMS_2026.serviceCosts.company,
  serviceCompanyOther: FORMS_2026.serviceCosts.companyOther,
};

const clamp = (v: number, lo: number, hi: number) => Math.min(Math.max(Number.isFinite(v) ? v : lo, lo), hi);
const pos = (v: number) => Math.max(0, v);

function sanitize(i: Inputs): Inputs {
  return {
    ...i,
    revenue: clamp(i.revenue, 0, 10_000_000),
    costs: clamp(i.costs, 0, 10_000_000),
    payout: clamp(i.payout, 0, 1),
    serviceJdg: clamp(i.serviceJdg, 0, 100_000),
    serviceCompany: clamp(i.serviceCompany, 0, 100_000),
    serviceCompanyOther: clamp(i.serviceCompanyOther, 0, 100_000),
    partners: i.partners === 2 ? 2 : 1,
  };
}

/** Roczne składki społeczne (z FP) dla danego wariantu ZUS. */
export function annualSocial(kind: JdgZus, sickness: boolean, P: FormsParams = FORMS_2026): number {
  const z = P.zus[kind];
  return 12 * (z.emerytalna + z.rentowa + z.wypadkowa + z.fp + (sickness ? z.chorobowa : 0));
}

/* ───────────── JDG — podatek liniowy ───────────── */

export function jdgLinear(inp: Inputs, P: FormsParams = FORMS_2026): Scenario {
  const i = sanitize(inp);
  const revenue = 12 * i.revenue;
  const businessCosts = 12 * i.costs;
  const serviceCosts = 12 * i.serviceJdg;
  const profit = revenue - businessCosts - serviceCosts;

  const social = annualSocial(i.jdgZus, i.sickness, P);
  // dochód po odliczeniu składek społecznych — podstawa składki zdrowotnej i daniny
  const income = profit - social;
  const health = Math.max(P.health.linearRate * pos(income), 12 * P.health.linearMinMonthly);
  const healthDeduction = Math.min(health, P.health.linearDeductionLimit);
  const pitBase = pos(income - healthDeduction);
  const pit = P.pit.linear * pitBase;
  const solidarity = P.pit.solidarityRate * pos(income - P.pit.solidarityThreshold);
  const taxes = pit + solidarity;

  const notes: string[] = [];
  if (profit <= 0) notes.push('Brak dochodu — nie ma podatku, ale składki ZUS i minimalna składka zdrowotna obowiązują.');
  if (solidarity > 0) notes.push('Dochód powyżej 1 mln zł — uwzględniono 4% daniny solidarnościowej od nadwyżki.');
  if (i.jdgZus !== 'full') notes.push('Preferencyjne składki i ulga na start przysługują czasowo (6 i 24 miesiące).');
  if (i.partners === 2) notes.push('JDG prowadzi jedna osoba — porównanie ze spółką kilku wspólników jest poglądowe.');

  return {
    key: 'jdg',
    name: 'JDG — podatek liniowy',
    revenue,
    businessCosts,
    serviceCosts,
    profit,
    taxes,
    social,
    health,
    toOwner: profit - social - health - taxes,
    retained: 0,
    taxLines: [
      { key: 'pit', label: 'PIT liniowy 19%', value: pit },
      ...(solidarity > 0 ? [{ key: 'solidarity', label: 'Danina solidarnościowa 4%', value: solidarity }] : []),
    ],
    approximate: i.partners === 2,
    unavailable: false,
    notes,
  };
}

/* ───────────── Spółka z o.o. — wspólne ───────────── */

function companyBase(i: Inputs, P: FormsParams) {
  const revenue = 12 * i.revenue;
  const businessCosts = 12 * i.costs;
  const serviceCosts = 12 * (i.serviceCompany + i.serviceCompanyOther);
  const profit = revenue - businessCosts - serviceCosts;
  // jedyny wspólnik sp. z o.o. podlega ZUS jak przedsiębiorca — pełne składki, bez ulg na start
  const ownerSocial = i.partners === 1 ? annualSocial('full', i.sickness, P) : 0;
  const ownerHealth = i.partners === 1 ? 12 * P.health.soleShareholderMonthly : 0;
  const smallTaxpayer = revenue * (1 + P.vatForSmallTaxpayerProxy) <= P.cit.smallTaxpayerGrossLimit;
  return { revenue, businessCosts, serviceCosts, profit, ownerSocial, ownerHealth, smallTaxpayer };
}

/** Czy przysługuje 9% CIT przy podanych odpowiedziach. */
export function reducedCitAvailable(inp: Inputs, P: FormsParams = FORMS_2026): boolean {
  const i = sanitize(inp);
  const { revenue, smallTaxpayer } = companyBase(i, P);
  return smallTaxpayer && revenue <= P.cit.reducedRevenueLimit && !i.fromTransformation;
}

/* ───────────── Spółka z o.o. — klasyczny CIT ───────────── */

export function companyClassic(inp: Inputs, P: FormsParams = FORMS_2026): Scenario {
  const i = sanitize(inp);
  const b = companyBase(i, P);
  const reduced = reducedCitAvailable(i, P);
  const rate = reduced ? P.cit.reduced : P.cit.standard;

  const cit = rate * pos(b.profit);
  const afterCit = b.profit - cit;
  const dividend = afterCit > 0 ? i.payout * afterCit : 0;
  const dividendPit = P.pit.dividend * dividend;
  const retained = afterCit - dividend;

  const notes: string[] = [];
  if (!reduced) {
    if (i.fromTransformation) notes.push('Spółka z przekształcenia JDG nie stosuje 9% CIT w roku powstania i w roku następnym — przyjęto 19%.');
    else notes.push('Przychody przekraczają limit 9% CIT (2 mln EUR) — przyjęto 19%.');
  }
  const margin = b.revenue > 0 ? b.profit / b.revenue : 0;
  if (b.profit > 0 && margin <= P.cit.minimumTaxProfitabilityThreshold)
    notes.push('Rentowność do 2% — może wystąpić podatek minimalny, którego model nie liczy.');
  if (b.profit <= 0) notes.push('Strata — brak CIT i dywidendy; strata zostaje w spółce do rozliczenia w kolejnych latach.');
  if (retained > 0 && i.payout < 1) notes.push('Zysk zatrzymany jest już po CIT; przy późniejszej wypłacie zapłacisz 19% PIT od dywidendy.');

  return {
    key: 'cit',
    name: 'Spółka z o.o. — klasyczny CIT',
    revenue: b.revenue,
    businessCosts: b.businessCosts,
    serviceCosts: b.serviceCosts,
    profit: b.profit,
    taxes: cit + dividendPit,
    social: b.ownerSocial,
    health: b.ownerHealth,
    toOwner: dividend - dividendPit - b.ownerSocial - b.ownerHealth,
    retained,
    taxLines: [
      { key: 'cit', label: `CIT ${Math.round(rate * 100)}%`, value: cit },
      { key: 'dividendPit', label: 'PIT od dywidendy 19%', value: dividendPit },
    ],
    approximate: (b.profit > 0 && margin <= P.cit.minimumTaxProfitabilityThreshold),
    unavailable: false,
    notes,
  };
}

/* ───────────── Spółka z o.o. — estoński CIT ───────────── */
// Podatek płaci się dopiero przy wypłacie zysku. Ryczałt (10% / 20%) liczony jest od wypłacanego zysku netto
// i nie pomniejsza kwoty wypłaty, więc spółka musi mieć środki na wypłatę i ryczałt łącznie:
//   wypłata D = udział × zysk / (1 + stawka), ryczałt = stawka × D,
//   PIT wspólnika = 19% × D − (90% lub 70%) × ryczałt.

export function companyEstonian(inp: Inputs, P: FormsParams = FORMS_2026): Scenario {
  const i = sanitize(inp);
  const b = companyBase(i, P);
  const rate = b.smallTaxpayer ? P.estonian.smallRate : P.estonian.standardRate;
  const credit = b.smallTaxpayer ? P.estonian.smallDividendCredit : P.estonian.standardDividendCredit;

  const distributed = b.profit > 0 ? (i.payout * b.profit) / (1 + rate) : 0;
  const lumpSum = rate * distributed;
  const dividendPit = pos(P.pit.dividend * distributed - credit * lumpSum);
  const retained = b.profit - distributed - lumpSum;

  const notes: string[] = [];
  if (!b.smallTaxpayer) notes.push('Przychody powyżej limitu małego podatnika — ryczałt 20%, odliczenie od PIT 70%.');
  if (i.estonianStatus === 'no') notes.push('Spółka nie spełnia warunków estońskiego CIT (m.in. zatrudnienie min. 3 osób niebędących wspólnikami).');
  if (i.estonianStatus === 'unknown') notes.push('Wynik zakłada spełnienie warunków estońskiego CIT — do potwierdzenia (zatrudnienie, przychody pasywne, wspólnicy).');
  if (retained > 0) notes.push('Zysk w spółce nie jest jeszcze opodatkowany — ryczałt i PIT zapłacisz przy jego wypłacie.');
  if (b.profit <= 0) notes.push('Strata — brak wypłaty i ryczałtu.');

  return {
    key: 'estonian',
    name: 'Spółka z o.o. — estoński CIT',
    revenue: b.revenue,
    businessCosts: b.businessCosts,
    serviceCosts: b.serviceCosts,
    profit: b.profit,
    taxes: lumpSum + dividendPit,
    social: b.ownerSocial,
    health: b.ownerHealth,
    toOwner: distributed - dividendPit - b.ownerSocial - b.ownerHealth,
    retained,
    taxLines: [
      { key: 'lumpSum', label: `Ryczałt (estoński CIT) ${Math.round(rate * 100)}%`, value: lumpSum },
      { key: 'dividendPit', label: `PIT od dywidendy po odliczeniu ${Math.round(credit * 100)}% ryczałtu`, value: dividendPit },
    ],
    approximate: i.estonianStatus === 'unknown',
    unavailable: i.estonianStatus === 'no',
    notes,
  };
}

/* ───────────── Porównanie ───────────── */

export function compare(inp: Inputs, P: FormsParams = FORMS_2026): Result {
  const i = sanitize(inp);
  const b = companyBase(i, P);
  const globalNotes: string[] = [];
  if (i.revenue === 0) globalNotes.push('Wpisz przychód, aby zobaczyć porównanie.');
  if (i.partners === 2) globalNotes.push('Przy dwóch lub więcej wspólnikach kwoty „dla właściciela” dotyczą wszystkich wspólników łącznie.');
  return {
    inputs: i,
    scenarios: [jdgLinear(i, P), companyClassic(i, P), companyEstonian(i, P)],
    smallTaxpayer: b.smallTaxpayer,
    reducedCit: reducedCitAvailable(i, P),
    estonianRate: b.smallTaxpayer ? P.estonian.smallRate : P.estonian.standardRate,
    globalNotes,
  };
}

/* ───────────── Podsumowanie do formularza ───────────── */

const fmt = (v: number) => `${Math.round(v).toLocaleString('pl-PL')} zł`;

export function summaryText(r: Result, view: 'month' | 'year'): string {
  const d = view === 'month' ? 12 : 1;
  const unit = view === 'month' ? 'miesięcznie' : 'rocznie';
  const i = r.inputs;
  const lines = [
    `Symulacja „Twoja firma w trzech scenariuszach” (stawki ${FORMS_2026.year}, kwoty ${unit})`,
    `Przychód: ${fmt(i.revenue)} / mies., koszty działalności: ${fmt(i.costs)} / mies.`,
    `Wypłata zysku ze spółki: ${Math.round(i.payout * 100)}%, wspólnicy: ${i.partners === 1 ? 'jeden' : 'dwóch lub więcej'}`,
    `ZUS w JDG: ${i.jdgZus === 'full' ? 'pełny' : i.jdgZus === 'pref' ? 'preferencyjny' : 'ulga na start'}${i.sickness ? ', z chorobowym' : ''}`,
    `Przekształcenie JDG w spółkę: ${i.fromTransformation ? 'tak' : 'nie'}; warunki estońskiego CIT: ${i.estonianStatus === 'yes' ? 'spełnione' : i.estonianStatus === 'no' ? 'niespełnione' : 'do sprawdzenia'}`,
    '',
    ...r.scenarios.map(
      (s) =>
        `${s.name}${s.unavailable ? ' (niedostępny)' : s.approximate ? ' (orientacyjnie)' : ''}: dla właściciela ${fmt(s.toOwner / d)}, w spółce ${fmt(s.retained / d)}, podatki ${fmt(s.taxes / d)}, składki ${fmt((s.social + s.health) / d)}, koszty obsługi ${fmt(s.serviceCosts / d)}`,
    ),
    '',
    'Wynik symulacji jest orientacyjny i wymaga potwierdzenia w analizie.',
  ];
  return lines.join('\n');
}
