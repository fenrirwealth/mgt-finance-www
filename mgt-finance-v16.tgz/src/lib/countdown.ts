// Licznik „dni do najbliższego terminu” w kalendarzu podatkowym. Daty jako 'RRRR-MM-DD' (czas lokalny).
/** Liczba pełnych dni kalendarzowych od dziś do terminu (0 = termin dziś; nigdy ujemna). */
export function daysUntil(dateISO: string, todayISO: string): number {
  const d = Math.round((Date.parse(dateISO + 'T00:00:00Z') - Date.parse(todayISO + 'T00:00:00Z')) / 864e5);
  return Number.isFinite(d) ? Math.max(0, d) : 0;
}
/** Polska forma rzeczownika „dzień” po liczebniku: 1 dzień, 0/2/5/11/22 dni. */
export const daysWord = (n: number) => (n === 1 ? 'dzień' : 'dni');
/** Pełny, czytelny tekst — np. do aria-label lub tytułu. */
export const countdownText = (n: number) => (n === 0 ? 'Dziś upływa najbliższy termin' : `${n} ${daysWord(n)} do najbliższego terminu`);
