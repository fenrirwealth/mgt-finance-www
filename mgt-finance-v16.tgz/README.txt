MGT FINANCE — SESJA WIZERUNKOWA I TYPOGRAFIA
Przygotowano: 3 października 2026 r.

STATUS
Gotowy, lokalnie zbudowany projekt Astro. Zmiany nie zostały opublikowane na mgtfinance.eu.
Podstawą jest lokalny projekt z poprzedniego wdrożenia z 2 października 2026 r.
Przed publikacją porównać z aktualnym projektem w Coolify, jeżeli po tej dacie wprowadzano inne zmiany.

ZMIANY
- 12 spójnych, wygenerowanych fotografii; brak rozpoznawalnych twarzy.
- 66 eksportów: WebP i zapasowe JPG, kadry desktop/mobile, 7 miniatur usług, baner i kadr do udostępniania.
- Każdy plik zdjęciowy ma poniżej 300 000 bajtów.
- Zdjęcia są ilustracjami wizerunkowymi; nie dokumentują faktycznej siedziby ani zespołu MGT Finance.
- Duże nagłówki: Cormorant Garamond 500. Treści, menu, formularze i narzędzia: Inter.
- Oryginalne logo zachowane. Polskie alty opisowe; elementy dekoracyjne mają alt="".
- CampaignPhoto.astro renderuje picture/source po stronie serwera. Nie wymaga dodatkowego JavaScript.
- Siedem usług ma indywidualne fotografie. Strona główna, O nas, blog, kontakt i strony narzędzi zostały dopasowane do nowej sesji.
- Zachowano dotychczasową logikę formularzy, kalkulatorów i API.

BUDOWANIE
Wymagane: Node.js 22.12+ oraz pnpm 12.8.1.
pnpm install --frozen-lockfile --ignore-scripts
pnpm build
HOST=0.0.0.0 PORT=4321 node dist/server/entry.mjs

WDROŻENIE COOLIFY
Projekt zawiera Dockerfile dla portu 4321. Zachować istniejącą domenę, zmienne środowiskowe, SMTP i konfigurację proxy.
Osobny plik mgt-finance-coolify.Dockerfile zawiera komplet źródeł i zdjęć jako osadzony pakiet — do dotychczasowego wdrożenia z treści Dockerfile bez Git.
Nie uruchamiać starego skryptu scripts/fetch-images.mjs: pobiera poprzednie fotografie. Nowe zasoby są już w public/img/mgt.
Kompilację Astro sprawdzono lokalnie; kontenera Docker nie uruchamiano w tym środowisku.

KONTROLA
Raporty walidacji, metadane plików oraz zrzuty przed/podgląd po znajdują się w osobnych paczkach dostawy.
Zrzuty po zmianach przedstawiają lokalną wersję aplikacji, nie opublikowaną witrynę.

WYCOFANIE
Zmiana dotyczy źródeł i plików statycznych, bez migracji bazy danych. W Coolify zachować poprzednie udane wdrożenie do przywrócenia.

SYMULATOR „TWOJA FIRMA W TRZECH SCENARIUSZACH” (październik 2026)
- Moduł: src/components/BusinessFormsSimulator.astro (na /kalkulatory#scenariusze, karta na stronie głównej).
- Logika: src/lib/business-forms.ts. Stawki, limity, źródła i data weryfikacji: src/data/business-forms-2026.ts — aktualizować co rok.
- Testy rachunkowe: pnpm test (node --test, Node 22.18+).
- Przycisk „Umów analizę z MGT Finance” zapisuje podsumowanie w sessionStorage (klucz mgt:scenario) i otwiera /kontakt; formularz pokazuje podsumowanie przed wysłaniem. Kwoty nie trafiają do adresu URL.

ZESTAWIENIE ENERGII I EMISJI (/zestawienie-emisji) — etap 2
- Strona: src/pages/zestawienie-emisji.astro, komponent: src/components/EmissionsTool.astro
- Współczynniki (wersjonowane, z metadanymi źródeł): src/data/emission-factors.ts — aktualizuj po publikacjach KOBiZE (grudzień)
- Obliczenia: src/lib/emissions.ts · PDF (jsPDF, w przeglądarce): src/lib/emissions-pdf.ts
- Fonty PDF (podzbiory Inter/Cormorant, OFL): public/fonts/pdf/
- Testy: pnpm test (tests/emissions.test.ts, tests/emissions-pdf.test.ts — test PDF używa pdftotext, jeśli jest dostępny)
- Dane użytkownika nie są wysyłane na serwer; przekazanie do formularza kontaktowego tylko przez sessionStorage (klucz mgt:scenario) po kliknięciu CTA.
