import { deadlinesForYear, toICS } from '../lib/deadlines.js';
export const prerender = false;
export async function GET({ url }) {
  const who = (url.searchParams.get('who') || '').split(',').filter(Boolean);
  const alarm = Math.min(14, Math.max(0, parseInt(url.searchParams.get('alarm') || '2', 10) || 2));
  const y = new Date().getFullYear();
  let ev = [...deadlinesForYear(y), ...deadlinesForYear(y + 1)];
  if (who.length) ev = ev.filter((e) => e.who.some((w) => who.includes(w)));
  return new Response(toICS(ev, alarm), { headers: { 'content-type': 'text/calendar; charset=utf-8', 'content-disposition': 'inline; filename="kalendarz-podatkowy-mgt.ics"', 'cache-control': 'public, max-age=21600' } });
}
