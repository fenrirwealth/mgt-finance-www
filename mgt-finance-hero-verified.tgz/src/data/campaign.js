import photos from './campaign.json';
export const photo=(id)=>photos.find(p=>p.id===id);
export const servicePhotos={'/ksiegowosc-spolki-z-o-o':3,'/ksiega-przychodow-i-rozchodow':4,'/kadry-i-place':7,'/doradztwo-podatkowe':8,'/rejestracja-podmiotow-gospodarczych':9,'/zarzadzanie-wierzytelnosciami':10,'/wspolpraca-z-kancelaria-prawna':11};
export const pagePhotos={...servicePhotos,'/o-nas':5,'/kontakt':5,'/wycena':2,'/cennik-uslug-ksiegowych':6,'/kalkulatory':12,'/kalendarz-podatkowy':12,'/e-urzedy':12,'/aktualnosci':12,'/blog':12};
export const compactPages=['/kontakt','/wycena','/cennik-uslug-ksiegowych','/kalkulatory','/kalendarz-podatkowy','/e-urzedy','/aktualnosci','/blog'];
